"""Escrow request/response schemas."""
from datetime import datetime
from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field

from app.domain.entities.enums import EscrowStatus
from app.schemas.base import ORMModel


class CreateEscrowRequest(BaseModel):
    payee_email: EmailStr
    amount: Decimal = Field(gt=0, max_digits=18, decimal_places=2)
    currency: str = Field(default="GBP", min_length=3, max_length=3)
    description: str = Field(min_length=1, max_length=2000)
    terms: str | None = Field(default=None, max_length=5000)
    external_reference: str | None = Field(default=None, max_length=255)


class CancelEscrowRequest(BaseModel):
    reason: str | None = Field(default=None, max_length=1000)


class FundEscrowRequest(BaseModel):
    idempotency_key: str | None = Field(default=None, max_length=255)


class ReleaseEscrowRequest(BaseModel):
    idempotency_key: str | None = Field(default=None, max_length=255)


class RefundEscrowRequest(BaseModel):
    reason: str | None = Field(default=None, max_length=1000)
    idempotency_key: str | None = Field(default=None, max_length=255)


class EscrowPublic(ORMModel):
    id: UUID
    payer_id: UUID
    payee_id: UUID
    status: EscrowStatus
    amount: Decimal
    fee_amount: Decimal
    currency: str
    description: str
    terms: str | None
    external_reference: str | None
    funded_at: datetime | None
    released_at: datetime | None
    refunded_at: datetime | None
    cancelled_at: datetime | None
    expires_at: datetime | None
    created_at: datetime
    updated_at: datetime
