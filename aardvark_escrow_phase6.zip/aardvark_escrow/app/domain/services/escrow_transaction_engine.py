"""Escrow transaction engine.

Implements the money-moving half of the escrow lifecycle. Combines
`EscrowStateMachine` (Phase 5) with the row-locking discipline
`WalletService` established (Phase 4) under one `UnitOfWork`, so a
wallet's balance/held_balance and an escrow's status always move
together or not at all.

**Ordering rule, load-bearing:** in every method below, the state
transition is validated (and applied to the in-memory `Escrow`) *before*
any wallet balance is touched. This was not the first draft — an earlier
version mutated `held_balance` first and checked the transition's
legality afterward, so refunding an already-RELEASED escrow (a state
with no legal transition to REFUNDED) still executed a wallet UPDATE that
tried to send `held_balance` negative, which Postgres's own CHECK
constraint caught — but as an ugly `IntegrityError` deep in a flush,
instead of the clean `InvalidStateTransitionError` this should have been.
Validating the transition first means an illegal call never touches a
wallet at all; any exception raised afterward (e.g. insufficient funds)
still rolls back cleanly via `UnitOfWork`, discarding the in-memory
status change along with everything else.

**Money model -- an authorization hold, not an immediate transfer.**
Funding an escrow does not remove money from the payer's spendable
`balance`; it increases `held_balance`, locking that amount without
moving it (the same mental model as a card pre-authorization).
`available_balance` (`balance - held_balance`, `Wallet`, Phase 2) is what
actually shrinks. `balance` only decreases when funds are *released* to
the payee. A *refund* simply cancels the hold -- `held_balance` decreases,
`balance` was never touched, because the money never left. This is
exactly why `Wallet.held_balance` exists and why `WalletService.withdraw`
checks `available_balance`, not `balance` -- Phase 4 built the column,
Phase 6 is what actually uses it.

**Endpoint-to-transition mapping.** See
`escrow_state_machine.py`'s module docstring for the full reasoning; in
short:

    fund     (payer)         AWAITING_PAYMENT -> FUNDED -> IN_PROGRESS
    approve  (payee)         IN_PROGRESS -> AWAITING_APPROVAL (no money moves)
    release  (payer/admin)   AWAITING_APPROVAL -> RELEASED, or DISPUTED -> RELEASED
    refund   (payee/admin)   {FUNDED,IN_PROGRESS,AWAITING_APPROVAL} -> REFUNDED -> CLOSED,
                              or DISPUTED -> REFUNDED -> CLOSED

**Deadlock avoidance.** `release` is the only operation here that locks
two different wallets at once (debiting the payer, crediting the payee).
Both are always locked in a fixed order -- sorted by wallet ID, regardless
of which one is "payer" and which is "payee" for this particular escrow --
so two concurrent releases (say, of two different escrows between the
same two users with payer/payee reversed) can never lock in opposite
orders and deadlock.

**Idempotency** is checked against `EscrowTransaction.idempotency_key`
(unique, Phase 2) rather than either wallet's ledger, since `release`
touches two wallet ledgers but only ever produces one `EscrowTransaction`
-- the single record of "did this escrow operation already happen."
"""
from uuid import UUID

from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import (
    AuthorizationError,
    ConflictError,
    InsufficientFundsError,
    NotFoundError,
)
from app.database.unit_of_work import UnitOfWork
from app.domain.entities.audit import AuditAction, AuditLog
from app.domain.entities.enums import (
    EscrowStatus,
    EscrowTransactionType,
    UserRole,
    WalletTransactionType,
)
from app.domain.entities.escrow import Escrow, EscrowTransaction
from app.domain.entities.user import User
from app.domain.entities.wallet import Wallet, WalletTransaction
from app.domain.services.escrow_state_machine import EscrowStateMachine
from app.domain.services.wallet_service import WalletService


class EscrowTransactionEngine:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def fund(
        self,
        escrow_id: UUID,
        *,
        current_user: User,
        idempotency_key: str | None = None,
    ) -> Escrow:
        async with UnitOfWork(self._session) as uow:
            escrow = await self._load_escrow_for_party(uow, escrow_id, current_user)

            if current_user.id != escrow.payer_id:
                raise AuthorizationError("Only the payer can fund this escrow")

            replayed = await self._check_replay(uow, idempotency_key)
            if replayed is not None:
                return replayed

            # Validate + apply the state transition before touching any
            # wallet -- see this module's docstring for why.
            funded_event = EscrowStateMachine.transition(
                escrow, EscrowStatus.FUNDED, actor_id=current_user.id
            )
            in_progress_event = EscrowStateMachine.transition(
                escrow, EscrowStatus.IN_PROGRESS, actor_id=current_user.id
            )

            payer_wallet = await self._lock_wallet_for_user(uow, escrow.payer_id)

            if payer_wallet.available_balance < escrow.amount:
                raise InsufficientFundsError(
                    f"Insufficient available balance to fund this escrow: have "
                    f"{payer_wallet.available_balance}, need {escrow.amount}"
                )

            payer_wallet.held_balance += escrow.amount
            wallet_txn = WalletTransaction(
                wallet_id=payer_wallet.id,
                type=WalletTransactionType.ESCROW_HOLD,
                amount=-escrow.amount,
                balance_after=payer_wallet.balance,
                description=f"Funds held for escrow {escrow.id}",
            )
            uow.session.add(wallet_txn)
            await uow.session.flush()

            uow.session.add(
                EscrowTransaction(
                    escrow_id=escrow.id,
                    type=EscrowTransactionType.DEPOSIT,
                    amount=escrow.amount,
                    wallet_transaction_id=wallet_txn.id,
                    idempotency_key=idempotency_key,
                )
            )
            uow.session.add(funded_event)
            uow.session.add(in_progress_event)

            uow.audit_log.add(
                AuditLog(
                    actor_id=current_user.id,
                    action=AuditAction.ESCROW_FUNDED,
                    resource_type="escrow",
                    resource_id=escrow.id,
                )
            )

            try:
                await uow.commit()
            except IntegrityError as exc:
                return await self._resolve_replay_after_conflict(uow, idempotency_key, exc)

            return escrow

    async def approve(self, escrow_id: UUID, *, current_user: User) -> Escrow:
        """Payee signals the deliverable is ready for the payer's review.

        No money moves -- see this module's docstring for why `approve`
        and `release` are kept as two distinct, non-overlapping steps.
        """
        async with UnitOfWork(self._session) as uow:
            escrow = await self._load_escrow_for_party(uow, escrow_id, current_user)

            if current_user.id != escrow.payee_id:
                raise AuthorizationError(
                    "Only the payee can mark this escrow's deliverable as ready"
                )

            uow.session.add(
                EscrowStateMachine.transition(
                    escrow, EscrowStatus.AWAITING_APPROVAL, actor_id=current_user.id
                )
            )
            uow.audit_log.add(
                AuditLog(
                    actor_id=current_user.id,
                    action=AuditAction.ESCROW_APPROVED,
                    resource_type="escrow",
                    resource_id=escrow.id,
                )
            )
            await uow.commit()
            return escrow

    async def release(
        self,
        escrow_id: UUID,
        *,
        current_user: User,
        idempotency_key: str | None = None,
    ) -> Escrow:
        is_admin = current_user.role == UserRole.ADMIN

        async with UnitOfWork(self._session) as uow:
            escrow = await self._load_escrow_for_party(
                uow, escrow_id, current_user, allow_admin=is_admin
            )

            if escrow.status == EscrowStatus.DISPUTED:
                if not is_admin:
                    raise AuthorizationError(
                        "Only an admin can release funds on a disputed escrow"
                    )
            elif current_user.id != escrow.payer_id and not is_admin:
                raise AuthorizationError("Only the payer can release funds to the payee")

            replayed = await self._check_replay(uow, idempotency_key)
            if replayed is not None:
                return replayed

            release_event = EscrowStateMachine.transition(
                escrow, EscrowStatus.RELEASED, actor_id=current_user.id
            )

            payer_wallet, payee_wallet = await self._lock_two_wallets_in_order(
                uow, escrow.payer_id, escrow.payee_id
            )

            payer_wallet.held_balance -= escrow.amount
            payer_wallet.balance -= escrow.amount
            payer_txn = WalletTransaction(
                wallet_id=payer_wallet.id,
                type=WalletTransactionType.ESCROW_RELEASE,
                amount=-escrow.amount,
                balance_after=payer_wallet.balance,
                description=f"Escrow {escrow.id} released to payee",
            )
            uow.session.add(payer_txn)

            # fee_amount is reserved for a future platform-fee model -- no
            # account exists yet to receive a deducted fee, so the payee
            # always receives the full amount for now (see the note in
            # docs/architecture.md).
            payee_wallet.balance += escrow.amount
            payee_txn = WalletTransaction(
                wallet_id=payee_wallet.id,
                type=WalletTransactionType.ESCROW_RELEASE,
                amount=escrow.amount,
                balance_after=payee_wallet.balance,
                description=f"Escrow {escrow.id} released from payer",
            )
            uow.session.add(payee_txn)
            await uow.session.flush()

            uow.session.add(
                EscrowTransaction(
                    escrow_id=escrow.id,
                    type=EscrowTransactionType.RELEASE,
                    amount=escrow.amount,
                    wallet_transaction_id=payee_txn.id,
                    idempotency_key=idempotency_key,
                )
            )
            uow.session.add(release_event)

            uow.audit_log.add(
                AuditLog(
                    actor_id=current_user.id,
                    action=AuditAction.ESCROW_RELEASED,
                    resource_type="escrow",
                    resource_id=escrow.id,
                )
            )

            try:
                await uow.commit()
            except IntegrityError as exc:
                return await self._resolve_replay_after_conflict(uow, idempotency_key, exc)

            return escrow

    async def refund(
        self,
        escrow_id: UUID,
        *,
        current_user: User,
        reason: str | None = None,
        idempotency_key: str | None = None,
    ) -> Escrow:
        is_admin = current_user.role == UserRole.ADMIN

        async with UnitOfWork(self._session) as uow:
            escrow = await self._load_escrow_for_party(
                uow, escrow_id, current_user, allow_admin=is_admin
            )

            if escrow.status == EscrowStatus.DISPUTED:
                if not is_admin:
                    raise AuthorizationError("Only an admin can refund a disputed escrow")
            elif current_user.id != escrow.payee_id and not is_admin:
                raise AuthorizationError(
                    "Only the payee can agree to refund this escrow before a "
                    "dispute is raised"
                )

            replayed = await self._check_replay(uow, idempotency_key)
            if replayed is not None:
                return replayed

            refunded_event = EscrowStateMachine.transition(
                escrow, EscrowStatus.REFUNDED, actor_id=current_user.id, reason=reason
            )
            closed_event = EscrowStateMachine.transition(
                escrow, EscrowStatus.CLOSED, actor_id=current_user.id
            )

            payer_wallet = await self._lock_wallet_for_user(uow, escrow.payer_id)

            # The hold is simply released -- balance was never debited in
            # the first place, so there's nothing to add back to it.
            payer_wallet.held_balance -= escrow.amount
            wallet_txn = WalletTransaction(
                wallet_id=payer_wallet.id,
                type=WalletTransactionType.ESCROW_REFUND,
                amount=escrow.amount,
                balance_after=payer_wallet.balance,
                description=f"Escrow {escrow.id} refunded to payer",
            )
            uow.session.add(wallet_txn)
            await uow.session.flush()

            uow.session.add(
                EscrowTransaction(
                    escrow_id=escrow.id,
                    type=EscrowTransactionType.REFUND,
                    amount=escrow.amount,
                    wallet_transaction_id=wallet_txn.id,
                    idempotency_key=idempotency_key,
                )
            )
            uow.session.add(refunded_event)
            uow.session.add(closed_event)

            uow.audit_log.add(
                AuditLog(
                    actor_id=current_user.id,
                    action=AuditAction.ESCROW_REFUNDED,
                    resource_type="escrow",
                    resource_id=escrow.id,
                )
            )

            try:
                await uow.commit()
            except IntegrityError as exc:
                return await self._resolve_replay_after_conflict(uow, idempotency_key, exc)

            return escrow

    # -- internal helpers ---------------------------------------------

    async def _load_escrow_for_party(
        self,
        uow: UnitOfWork,
        escrow_id: UUID,
        current_user: User,
        *,
        allow_admin: bool = False,
    ) -> Escrow:
        escrow = await uow.escrows.get_for_update(escrow_id)
        is_party = escrow is not None and current_user.id in (
            escrow.payer_id,
            escrow.payee_id,
        )
        if escrow is None or not (is_party or allow_admin):
            raise NotFoundError("Escrow not found")
        return escrow

    async def _lock_wallet_for_user(self, uow: UnitOfWork, user_id: UUID) -> Wallet:
        """Ensure the user has a wallet, then lock that specific row.

        Provisioning (via `WalletService.get_or_create_wallet`) happens
        in its own short-lived transaction -- see that method's docstring
        -- and the row is then locked here, inside this operation's own
        transaction, for the actual balance mutation.
        """
        wallet = await WalletService(self._session).get_or_create_wallet(user_id)
        locked = await uow.wallets.get_for_update(wallet.id)
        if locked is None:
            raise NotFoundError("Wallet not found")  # pragma: no cover - defensive
        return locked

    async def _lock_two_wallets_in_order(
        self, uow: UnitOfWork, payer_user_id: UUID, payee_user_id: UUID
    ) -> tuple[Wallet, Wallet]:
        """Lock the payer's and payee's wallets in a fixed global order.

        Provisions both first (so their IDs are known), then locks
        whichever wallet has the lexicographically smaller ID first,
        regardless of payer/payee role -- see this module's docstring for
        why that ordering is what prevents deadlocks between concurrent
        releases that involve the same two wallets in reversed roles.
        """
        wallet_service = WalletService(self._session)
        payer_wallet = await wallet_service.get_or_create_wallet(payer_user_id)
        payee_wallet = await wallet_service.get_or_create_wallet(payee_user_id)

        if str(payer_wallet.id) <= str(payee_wallet.id):
            locked_payer = await uow.wallets.get_for_update(payer_wallet.id)
            locked_payee = await uow.wallets.get_for_update(payee_wallet.id)
        else:
            locked_payee = await uow.wallets.get_for_update(payee_wallet.id)
            locked_payer = await uow.wallets.get_for_update(payer_wallet.id)

        if locked_payer is None or locked_payee is None:
            raise NotFoundError("Wallet not found")  # pragma: no cover - defensive
        return locked_payer, locked_payee

    async def _check_replay(
        self, uow: UnitOfWork, idempotency_key: str | None
    ) -> Escrow | None:
        """If this idempotency key was already used, return that result.

        Called *before* any mutation -- the common, non-racing case where
        the key is already committed from an earlier request. The
        IntegrityError-based path (`_resolve_replay_after_conflict`)
        handles the rarer case of two requests racing with the same key
        at the same time.
        """
        if idempotency_key is None:
            return None
        existing = await uow.escrows.get_transaction_by_idempotency_key(idempotency_key)
        if existing is None:
            return None
        escrow = await uow.escrows.get_by_id(existing.escrow_id)
        if escrow is None:
            return None  # pragma: no cover - defensive
        return escrow

    async def _resolve_replay_after_conflict(
        self, uow: UnitOfWork, idempotency_key: str | None, exc: IntegrityError
    ) -> Escrow:
        """Turn a replayed fund/release/refund into its original result.

        Called after `IntegrityError` from the unique constraint on
        `idempotency_key`. Re-fetches fresh rows rather than touching this
        transaction's now-expired objects -- `session.rollback()` expires
        every object in the session, and an async session can't do the
        implicit re-load that touching an expired attribute would
        normally trigger.
        """
        await uow.rollback()

        if idempotency_key is not None:
            existing = await uow.escrows.get_transaction_by_idempotency_key(
                idempotency_key
            )
            if existing is not None:
                escrow = await uow.escrows.get_by_id(existing.escrow_id)
                if escrow is not None:
                    return escrow

        raise ConflictError("This request has already been processed") from exc
