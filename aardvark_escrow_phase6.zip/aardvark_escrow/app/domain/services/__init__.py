"""Domain services.

Business logic that doesn't belong to a single entity lives here.
`AuthService` (Phase 3); `UserService` and `WalletService` (Phase 4);
`EscrowStateMachine` and `EscrowService` (Phase 5) for the non-financial
half of the escrow lifecycle; `EscrowTransactionEngine` (Phase 6) for
fund/approve/release/refund, the half that moves money. All of them
depend only on repository interfaces via
`app.database.unit_of_work.UnitOfWork`, never on FastAPI directly.
"""
