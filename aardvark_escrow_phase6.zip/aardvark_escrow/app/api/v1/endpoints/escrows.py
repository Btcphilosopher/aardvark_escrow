"""Escrow endpoints: create, list, get, cancel, fund, approve, release, refund."""
from uuid import UUID

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db
from app.domain.entities.user import User
from app.domain.services.escrow_service import EscrowService
from app.domain.services.escrow_transaction_engine import EscrowTransactionEngine
from app.schemas.escrow import (
    CancelEscrowRequest,
    CreateEscrowRequest,
    EscrowPublic,
    FundEscrowRequest,
    RefundEscrowRequest,
    ReleaseEscrowRequest,
)
from app.security.dependencies import get_current_user

router = APIRouter(prefix="/escrows", tags=["escrows"])


@router.post("", response_model=EscrowPublic, status_code=status.HTTP_201_CREATED)
async def create_escrow(
    body: CreateEscrowRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> EscrowPublic:
    escrow = await EscrowService(db).create_escrow(
        payer_id=current_user.id,
        payee_email=body.payee_email,
        amount=body.amount,
        currency=body.currency,
        description=body.description,
        terms=body.terms,
        external_reference=body.external_reference,
    )
    return EscrowPublic.model_validate(escrow)


@router.get("", response_model=list[EscrowPublic])
async def list_escrows(
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[EscrowPublic]:
    escrows = await EscrowService(db).list_escrows(
        current_user.id, limit=limit, offset=offset
    )
    return [EscrowPublic.model_validate(escrow) for escrow in escrows]


@router.get("/{escrow_id}", response_model=EscrowPublic)
async def get_escrow(
    escrow_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> EscrowPublic:
    escrow = await EscrowService(db).get_escrow(escrow_id, user_id=current_user.id)
    return EscrowPublic.model_validate(escrow)


@router.post("/{escrow_id}/cancel", response_model=EscrowPublic)
async def cancel_escrow(
    escrow_id: UUID,
    body: CancelEscrowRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> EscrowPublic:
    escrow = await EscrowService(db).cancel_escrow(
        escrow_id, user_id=current_user.id, reason=body.reason
    )
    return EscrowPublic.model_validate(escrow)


@router.post("/{escrow_id}/fund", response_model=EscrowPublic)
async def fund_escrow(
    escrow_id: UUID,
    body: FundEscrowRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> EscrowPublic:
    escrow = await EscrowTransactionEngine(db).fund(
        escrow_id, current_user=current_user, idempotency_key=body.idempotency_key
    )
    return EscrowPublic.model_validate(escrow)


@router.post("/{escrow_id}/approve", response_model=EscrowPublic)
async def approve_escrow(
    escrow_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> EscrowPublic:
    escrow = await EscrowTransactionEngine(db).approve(escrow_id, current_user=current_user)
    return EscrowPublic.model_validate(escrow)


@router.post("/{escrow_id}/release", response_model=EscrowPublic)
async def release_escrow(
    escrow_id: UUID,
    body: ReleaseEscrowRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> EscrowPublic:
    escrow = await EscrowTransactionEngine(db).release(
        escrow_id, current_user=current_user, idempotency_key=body.idempotency_key
    )
    return EscrowPublic.model_validate(escrow)


@router.post("/{escrow_id}/refund", response_model=EscrowPublic)
async def refund_escrow(
    escrow_id: UUID,
    body: RefundEscrowRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> EscrowPublic:
    escrow = await EscrowTransactionEngine(db).refund(
        escrow_id,
        current_user=current_user,
        reason=body.reason,
        idempotency_key=body.idempotency_key,
    )
    return EscrowPublic.model_validate(escrow)
