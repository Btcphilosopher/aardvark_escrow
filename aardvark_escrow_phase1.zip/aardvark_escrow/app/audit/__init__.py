"""Audit logging.

Phase 9 adds an AuditService that writes an immutable AuditLog row for
every security- or money-relevant action (login, escrow state transition,
fund/release/refund, dispute lifecycle, admin action, settings change).
Audit records are append-only: no update or delete path is ever exposed.
"""
