"""Pydantic request/response schemas.

Kept separate from `app.domain.entities` deliberately — API contracts and
persistence models are allowed to diverge, and this package is where that
boundary is enforced. A shared ORM-mode base model is added here in
Phase 3 once the first schemas land.
"""
