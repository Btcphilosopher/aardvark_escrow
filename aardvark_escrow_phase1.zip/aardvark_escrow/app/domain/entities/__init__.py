"""Domain entities.

Phase 2 adds the concrete SQLAlchemy models here: User, Wallet, Escrow,
EscrowTransaction, EscrowEvent, Dispute, Evidence, Notification, AuditLog,
APIKey, RefreshToken. Phase 5 layers the escrow state machine on top of
the Escrow entity specifically.
"""
