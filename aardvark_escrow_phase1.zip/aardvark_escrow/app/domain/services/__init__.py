"""Domain services.

Business logic that doesn't belong to a single entity lives here — e.g.
EscrowStateMachine (Phase 5), EscrowTransactionEngine (Phase 6),
WalletService (Phase 4). Domain services depend only on repository
interfaces, never on FastAPI or SQLAlchemy session objects directly.
"""
