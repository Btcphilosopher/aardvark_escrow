"""Repository interfaces.

Each entity gets a repository protocol here (e.g. EscrowRepository,
WalletRepository) defining the persistence contract the domain/service
layer depends on, with a SQLAlchemy implementation living alongside it.
This is what lets domain and service tests run against an in-memory fake
without touching Postgres. Landed in Phase 2 alongside the models.
"""
