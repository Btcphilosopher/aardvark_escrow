"""Aggregates all v1 API routers into a single mountable router.

Additional routers are wired in here as their phases land:
    Phase 3 — auth (register, login, refresh, logout)
    Phase 4 — users, wallet
    Phase 7 — escrows, disputes, audit, notifications
"""
from fastapi import APIRouter

from app.api.v1.endpoints import health

api_router = APIRouter()
api_router.include_router(health.router)
