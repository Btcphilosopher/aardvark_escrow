"""Celery application configuration.

Task modules register themselves via `include=` as each phase introduces
them: notifications.tasks (Phase 8), reports.tasks (Phase 9),
reconciliation.tasks (Phase 8).
"""
from celery import Celery

from app.core.config import settings

celery_app = Celery(
    "aardvark_escrow",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=[],
)

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    worker_prefetch_multiplier=1,
    task_acks_late=True,
)
