"""Authentication endpoints and flows.

Phase 3 adds register/login/refresh/logout here, built on top of
app.security for token and password handling.
"""
