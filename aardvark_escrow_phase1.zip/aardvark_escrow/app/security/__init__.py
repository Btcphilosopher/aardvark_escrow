"""Authentication and cryptographic primitives.

Phase 3 adds: JWT access/refresh token issuance and verification (PyJWT),
password hashing (Passlib + Argon2), API key hashing/verification, and
idempotency-key + replay-protection helpers for financial endpoints.
"""
