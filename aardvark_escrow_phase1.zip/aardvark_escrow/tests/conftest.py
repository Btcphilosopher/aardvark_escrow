"""Shared pytest fixtures.

Phase 10 expands this with a test-database fixture (transactional
rollback per test) and factory-boy factories for every entity. For now it
only wires up an ASGI test client so the health endpoints are exercisable.
"""
from collections.abc import AsyncGenerator

import pytest
from httpx import ASGITransport, AsyncClient

from app.main import app


@pytest.fixture
async def client() -> AsyncGenerator[AsyncClient, None]:
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac
