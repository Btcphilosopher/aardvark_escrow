# Aardvark Escrow

A production-grade escrow platform: it holds funds between two or more
parties and releases, refunds, or arbitrates them according to strict,
auditable business rules. Built for marketplaces, procurement systems,
freelance platforms, and logistics companies that need a REST API they can
integrate against, not a spreadsheet with extra steps.

> **Status:** Phase 1 — project scaffolding and architecture. The service
> boots, exposes health checks, and the full clean-architecture layout is
> in place. Domain models, auth, and the escrow engine itself land in the
> phases that follow (see [docs/architecture.md](docs/architecture.md)).

## Stack

FastAPI · SQLAlchemy 2.x (async) · Alembic · PostgreSQL · Redis · Celery ·
Pydantic v2 · PyJWT · Passlib (Argon2) · Structlog · Prometheus ·
OpenTelemetry · ReportLab · Pytest · Docker

## Quickstart

```bash
cp .env.example .env
docker compose up --build
```

The API comes up on `http://localhost:8000`, with interactive docs at
`http://localhost:8000/api/v1/docs`.

Check it's alive:

```bash
curl http://localhost:8000/api/v1/health
curl http://localhost:8000/api/v1/health/ready   # verifies DB connectivity
```

## Local development without Docker

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env   # then point DATABASE_URL/REDIS_URL at local services
python main.py
```

Run the test suite:

```bash
pytest --cov=app
```

## Project layout

```
app/
  main.py            FastAPI application factory
  core/               settings, logging, exception hierarchy
  database/           async engine, session factory, declarative base
  domain/
    entities/          SQLAlchemy models (Phase 2)
    repositories/       persistence interfaces (Phase 2)
    services/           business logic (Phase 5, 6)
  events/              domain event base class + bus (Phase 5/6)
  security/            JWT, password hashing, idempotency (Phase 3)
  auth/                register/login/refresh/logout (Phase 3)
  schemas/             Pydantic request/response models
  middleware/          request context, rate limiting
  api/v1/              versioned REST endpoints
  workers/             Celery app + tasks
  audit/               immutable audit logging (Phase 9)
  notifications/       notification delivery (Phase 8)
migrations/           Alembic environment + versions
tests/                 pytest suite
docs/                  architecture, ER diagrams, guides
docker/                per-service Dockerfiles
scripts/               entrypoint / ops scripts
```

See [docs/architecture.md](docs/architecture.md) for the full design
rationale, the escrow state machine, and the phased build plan.

## Build phases

1. **Project scaffolding and architecture** ← you are here
2. Database models and migrations
3. Authentication system
4. User and wallet services
5. Escrow domain model + state machine
6. Escrow transaction engine
7. REST API (escrows, disputes, audit, notifications)
8. Background workers
9. Audit and reporting
10. Testing (target: 90% coverage)
11. Documentation

Each phase leaves the project in a runnable, tested state before the next
begins.
