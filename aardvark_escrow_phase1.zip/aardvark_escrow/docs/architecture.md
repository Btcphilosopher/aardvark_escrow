# Architecture

## Goals

Aardvark Escrow holds money on behalf of two or more parties and moves it
only when the agreed conditions are met. Everything about the design
follows from that one sentence:

- **Correctness over speed.** Every fund-moving operation runs inside a
  database transaction with row-level locking; nothing is "eventually
  consistent" when it comes to a balance.
- **Auditability by construction.** Every state transition and every
  money movement writes an immutable audit record. There is no delete
  path for audit data.
- **Framework-agnostic domain.** Business rules (the escrow state
  machine, wallet invariants) live in `app/domain` and know nothing about
  FastAPI, SQLAlchemy sessions, or HTTP. They can be unit tested with
  plain Python objects.

## Layering (Clean Architecture / DDD)

```
┌─────────────────────────────────────────────┐
│  API layer (app/api)                         │  HTTP, request/response
│  — FastAPI routers, Pydantic schemas         │    mapping only. No
├─────────────────────────────────────────────┤    business logic.
│  Service layer (app/domain/services)         │  Orchestrates use cases:
│  — EscrowService, WalletService, ...          │    coordinates repos +
├─────────────────────────────────────────────┤    domain entities inside
│  Domain layer (app/domain/entities)          │    a Unit of Work.
│  — Escrow, Wallet, ... + invariants          │  Pure business rules.
├─────────────────────────────────────────────┤    No I/O.
│  Repository layer (app/domain/repositories)  │  Persistence interfaces;
│  — protocols + SQLAlchemy implementations    │    swappable for tests.
├─────────────────────────────────────────────┤
│  Infrastructure (app/database, app/workers)  │  Engine, sessions,
│  — Postgres, Redis, Celery                   │    Celery, migrations.
└─────────────────────────────────────────────┘
```

Dependencies point inward only: the API layer depends on services, services
depend on repository *interfaces* (not concrete SQLAlchemy code), and the
domain layer depends on nothing. This is what makes the escrow state
machine and wallet arithmetic testable without a running Postgres
instance.

A **Unit of Work** wraps each use case that touches more than one
repository (e.g. "release escrow" touches the escrow, both wallets, and
the audit log) so the whole operation commits or rolls back as one unit.

Cross-cutting concerns that don't belong to any single use case —
notifying a party that an escrow was funded, generating a report —
are modelled as **domain events** (`app/events`) and handled
asynchronously by Celery workers, keeping the request path fast and the
side effects retryable.

## Escrow state machine

```
CREATED
  │
  ▼
AWAITING_PAYMENT
  │
  ▼
FUNDED ──────────────┐
  │                   │
  ▼                   ▼
IN_PROGRESS        DISPUTED
  │                   │
  ▼                   ▼
AWAITING_APPROVAL   REFUNDED
  │                   │
  ▼                   ▼
RELEASED            CLOSED
```

Transitions are enforced by a single `EscrowStateMachine` (Phase 5) that
is the *only* code path allowed to change an escrow's status. Any
attempted illegal transition raises `InvalidStateTransitionError`
(`app/core/exceptions.py`) rather than silently no-opping, and every
successful transition writes an `EscrowEvent` + `AuditLog` row in the
same database transaction.

## Financial integrity

- All balance-changing operations run inside a single DB transaction and
  take a row lock (`SELECT ... FOR UPDATE`) on the wallet(s) involved,
  preventing two concurrent requests from double-spending the same
  balance.
- Idempotency keys are required on financial POST endpoints
  (`fund`, `release`, `refund`, `withdraw`, ...); replaying a request with
  the same key returns the original result instead of executing twice.
- Escrow release/refund is guarded so a given escrow can only ever be
  released or refunded once — enforced both at the state-machine level
  and with a unique constraint at the database level as a second line of
  defence.

## Security model

- **AuthN:** JWT access tokens (short-lived) + refresh tokens (longer-
  lived, stored hashed, revocable), plus API keys for server-to-server
  integration.
- **AuthZ:** Role-based access control; escrow parties can only act on
  escrows they're a party to, admins have a separate elevated role for
  dispute resolution.
- **Transport/request hardening:** rate limiting, secure headers, strict
  Pydantic request validation, replay protection + idempotency keys on
  financial endpoints.

See [security.md](security.md) *(added in Phase 3)* for the full threat
model and control list.

## Observability

- **Structured logs** (`structlog`) — every log line carries a
  `request_id`, and financial operations additionally carry `escrow_id` /
  `wallet_id`, via `contextvars`.
- **Metrics** (`prometheus-client`) — request latency/count, escrow state
  transition counts, transaction engine error rates.
- **Tracing** (`OpenTelemetry`) — end-to-end spans across the API →
  service → repository → Celery task boundary.
- **Probes** — `/health` (liveness), `/health/live`, `/health/ready`
  (checks DB connectivity) for orchestrator integration.

## Build phases

See the [README](../README.md#build-phases) for the phase list. Each
phase's code lands with its own explanation and leaves the project
runnable before the next phase begins — this document is updated as new
architectural decisions are made along the way.
