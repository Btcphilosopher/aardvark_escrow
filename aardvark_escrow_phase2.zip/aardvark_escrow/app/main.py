"""Application factory and ASGI entrypoint.

`app` (the module-level FastAPI instance at the bottom of this file) is
what Uvicorn/Gunicorn point at: `app.main:app`.
"""
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.v1.router import api_router
from app.core.config import settings
from app.core.exceptions import (
    AardvarkError,
    AuthenticationError,
    AuthorizationError,
    ConflictError,
    DomainError,
    NotFoundError,
    RateLimitExceededError,
)
from app.core.logging import configure_logging, get_logger
from app.middleware.request_context import RequestContextMiddleware

configure_logging()
logger = get_logger(__name__)

# Maps domain exception types to HTTP status codes. Checked in subclass
# order so e.g. InvalidStateTransitionError (a DomainError) still resolves
# to 422 without needing its own entry.
_ERROR_STATUS_MAP: dict[type[AardvarkError], int] = {
    NotFoundError: status.HTTP_404_NOT_FOUND,
    AuthenticationError: status.HTTP_401_UNAUTHORIZED,
    AuthorizationError: status.HTTP_403_FORBIDDEN,
    ConflictError: status.HTTP_409_CONFLICT,
    RateLimitExceededError: status.HTTP_429_TOO_MANY_REQUESTS,
    DomainError: status.HTTP_422_UNPROCESSABLE_ENTITY,
}


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    logger.info("application_startup", environment=settings.ENVIRONMENT)
    yield
    logger.info("application_shutdown")


def create_app() -> FastAPI:
    application = FastAPI(
        title=settings.PROJECT_NAME,
        openapi_url=f"{settings.API_V1_PREFIX}/openapi.json",
        docs_url=f"{settings.API_V1_PREFIX}/docs",
        redoc_url=f"{settings.API_V1_PREFIX}/redoc",
        lifespan=lifespan,
    )

    application.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    application.add_middleware(RequestContextMiddleware)

    _register_exception_handlers(application)

    application.include_router(api_router, prefix=settings.API_V1_PREFIX)

    return application


def _register_exception_handlers(application: FastAPI) -> None:
    @application.exception_handler(AardvarkError)
    async def handle_aardvark_error(request: Request, exc: AardvarkError) -> JSONResponse:
        http_status = status.HTTP_400_BAD_REQUEST
        for exc_type, mapped_status in _ERROR_STATUS_MAP.items():
            if isinstance(exc, exc_type):
                http_status = mapped_status
                break

        logger.warning(
            "domain_error",
            error_type=type(exc).__name__,
            detail=str(exc),
            path=request.url.path,
        )
        return JSONResponse(
            status_code=http_status,
            content={"error": type(exc).__name__, "detail": str(exc)},
        )


app = create_app()
