"""APIKey entity.

Supports server-to-server integration (a marketplace's backend calling
the Escrow API directly rather than acting as a logged-in user). Only a
hash of the key is ever stored — `key_prefix` is the short, non-secret
portion shown back to the user afterwards so they can identify which key
is which in a list, the same pattern GitHub/Stripe use for API keys.
"""
from datetime import datetime
from typing import TYPE_CHECKING
from uuid import UUID

from sqlalchemy import DateTime, Enum, ForeignKey, Index, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, TimestampMixin, UUIDPrimaryKeyMixin
from app.domain.entities.enums import APIKeyStatus

if TYPE_CHECKING:
    from app.domain.entities.user import User


class APIKey(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "api_keys"
    __table_args__ = (Index("ix_api_keys_user_id_status", "user_id", "status"),)

    user_id: Mapped[UUID] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    key_prefix: Mapped[str] = mapped_column(String(12), index=True, nullable=False)
    hashed_key: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    status: Mapped[APIKeyStatus] = mapped_column(
        Enum(APIKeyStatus, name="api_key_status"),
        nullable=False,
        default=APIKeyStatus.ACTIVE,
    )
    scopes: Mapped[list[str]] = mapped_column(JSONB, nullable=False, default=list)

    last_used_at: Mapped["datetime | None"] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    expires_at: Mapped["datetime | None"] = mapped_column(DateTime(timezone=True), nullable=True)
    revoked_at: Mapped["datetime | None"] = mapped_column(DateTime(timezone=True), nullable=True)

    user: Mapped["User"] = relationship(back_populates="api_keys")

    def __repr__(self) -> str:  # pragma: no cover - debugging aid only
        return f"<APIKey id={self.id} user_id={self.user_id} prefix={self.key_prefix}>"
