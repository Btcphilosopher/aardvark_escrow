# Architecture

## Goals

Aardvark Escrow holds money on behalf of two or more parties and moves it
only when the agreed conditions are met. Everything about the design
follows from that one sentence:

- **Correctness over speed.** Every fund-moving operation runs inside a
  database transaction with row-level locking; nothing is "eventually
  consistent" when it comes to a balance.
- **Auditability by construction.** Every state transition and every
  money movement writes an immutable audit record. There is no delete
  path for audit data.
- **Framework-agnostic domain.** Business rules (the escrow state
  machine, wallet invariants) live in `app/domain` and know nothing about
  FastAPI, SQLAlchemy sessions, or HTTP. They can be unit tested with
  plain Python objects.

## Layering (Clean Architecture / DDD)

```
┌─────────────────────────────────────────────┐
│  API layer (app/api)                         │  HTTP, request/response
│  — FastAPI routers, Pydantic schemas         │    mapping only. No
├─────────────────────────────────────────────┤    business logic.
│  Service layer (app/domain/services)         │  Orchestrates use cases:
│  — EscrowService, WalletService, ...          │    coordinates repos +
├─────────────────────────────────────────────┤    domain entities inside
│  Domain layer (app/domain/entities)          │    a Unit of Work.
│  — Escrow, Wallet, ... + invariants          │  Pure business rules.
├─────────────────────────────────────────────┤    No I/O.
│  Repository layer (app/domain/repositories)  │  Persistence interfaces;
│  — protocols + SQLAlchemy implementations    │    swappable for tests.
├─────────────────────────────────────────────┤
│  Infrastructure (app/database, app/workers)  │  Engine, sessions,
│  — Postgres, Redis, Celery                   │    Celery, migrations.
└─────────────────────────────────────────────┘
```

Dependencies point inward only: the API layer depends on services, services
depend on repository *interfaces* (not concrete SQLAlchemy code), and the
domain layer depends on nothing. This is what makes the escrow state
machine and wallet arithmetic testable without a running Postgres
instance.

A **Unit of Work** (`app/database/unit_of_work.py`, Phase 4) wraps each
use case that touches more than one repository — e.g. "release escrow"
touches the escrow, both wallets, and the audit log — so the whole
operation commits or rolls back as one unit. `AuthService`,
`UserService`, and `WalletService` all use it today; it was introduced a
phase ahead of the escrow transaction engine that actually needs to
coordinate two independent aggregates, so that engine gets to reuse it
rather than invent transaction handling under time pressure.

Cross-cutting concerns that don't belong to any single use case —
notifying a party that an escrow was funded, generating a report —
are modelled as **domain events** (`app/events`) and handled
asynchronously by Celery workers, keeping the request path fast and the
side effects retryable.

## Escrow state machine

```
CREATED ─────────┐
  │              │
  ▼              │
AWAITING_PAYMENT ┼──────► CANCELLED  (terminal)
  │              │
  ▼              │
FUNDED ──────────┤
  │              │
  ▼              ▼
IN_PROGRESS ──► DISPUTED
  │              │  ▲
  ▼              │  │  (also reachable from FUNDED and
AWAITING_        │  │   AWAITING_APPROVAL, both omitted
APPROVAL ────────┤  │   here to keep the diagram readable)
  │              │  │
  ▼              ▼  │
RELEASED ◄───────┘  │
 (terminal)         │
                     ▼
                  REFUNDED ──► CLOSED  (terminal)
```

The full transition table (`_LEGAL_TRANSITIONS` in
`escrow_state_machine.py`) is the source of truth; the diagram above
simplifies it slightly for readability. `EscrowStateMachine`
(`app/domain/services/escrow_state_machine.py`, Phase 5) is the *only*
code path allowed to change an escrow's status. Any attempted illegal
transition raises `InvalidStateTransitionError`
(`app/core/exceptions.py`) rather than silently no-opping, and every
successful transition returns an `EscrowEvent` for the caller to persist
in the same transaction as whatever else that use case does.

This graph deliberately widens the spec's two example paths in two
places, both exhaustively tested in `tests/test_escrow_state_machine.py`:

- **A dispute can be raised from FUNDED, IN_PROGRESS, or
  AWAITING_APPROVAL** — not only immediately after funding. A
  disagreement can surface at any point before release.
- **DISPUTED can resolve to RELEASED, not only REFUNDED** — the
  `Dispute` entity's `DisputeResolution` enum (Phase 2) already includes
  `RELEASE_TO_PAYEE` alongside `REFUND_TO_PAYER`, so the graph needs to
  support both outcomes a dispute can actually have.

CREATED and AWAITING_PAYMENT collapse into a single creation-time step in
practice: `EscrowService.create_escrow` (Phase 5) creates an escrow and
immediately advances it to AWAITING_PAYMENT in the same call, recording
both transitions as separate `EscrowEvent` rows. There's no dedicated
"activate" endpoint in the spec's endpoint list, so an escrow is
immediately actionable (ready to be funded) the moment it's created.

Phase 5 implemented the non-financial part of this graph: create, read,
list, cancel (only legal from CREATED/AWAITING_PAYMENT, before any money
is at stake). Phase 6's `EscrowTransactionEngine` implements the rest —
`fund`, `approve`, `release`, `refund` — combining this state machine
with `WalletService` under one `UnitOfWork` that locks a wallet (or two)
and the escrow together.

**Endpoint-to-transition mapping.** The spec names four endpoints —
fund, approve, release, refund — without specifying who calls which or
exactly what each does. Here's the resolution, chosen so each endpoint
has one clear, non-overlapping purpose:

| Endpoint  | Caller       | Transition(s)                                              | Moves money? |
|-----------|--------------|-------------------------------------------------------------|--------------|
| `fund`    | payer        | `AWAITING_PAYMENT → FUNDED → IN_PROGRESS`                    | yes — hold placed |
| `approve` | payee        | `IN_PROGRESS → AWAITING_APPROVAL`                            | no — signals deliverable is ready for review |
| `release` | payer/admin  | `AWAITING_APPROVAL → RELEASED`, or `DISPUTED → RELEASED`     | yes — hold converts to a transfer |
| `refund`  | payee/admin  | `{FUNDED,IN_PROGRESS,AWAITING_APPROVAL} → REFUNDED → CLOSED`, or `DISPUTED → REFUNDED → CLOSED` | yes — hold is released |

`release` and `refund` accept an admin caller specifically for the
`DISPUTED` starting state (an admin resolving a dispute); everywhere
else, only the payer (`release`) or payee (`refund`) can act, since
those are the two roles who'd actually be giving something up.

**Money model — an authorization hold, not an immediate transfer.**
Funding an escrow does not remove money from the payer's spendable
`balance`; it increases `held_balance` (the same mental model as a card
pre-authorization). `available_balance` is what actually shrinks.
`balance` only decreases when funds are released to the payee. A refund
simply cancels the hold — `held_balance` decreases, `balance` was never
touched, because the money never left. This is exactly why
`Wallet.held_balance` exists (Phase 2) and why `WalletService.withdraw`
checks `available_balance`, not `balance` — Phase 4 built the column,
Phase 6 is what actually uses it.

## Financial integrity

- All balance-changing operations run inside a single DB transaction and
  take a row lock (`SELECT ... FOR UPDATE`) on the wallet(s) involved,
  preventing two concurrent requests from double-spending the same
  balance. `WalletService.deposit`/`withdraw` (Phase 4) are the first real
  example; the Phase 6 escrow transaction engine follows the same
  pattern across two wallets and an escrow at once.
- **A subtle bug worth documenting explicitly:** a naive `SELECT ... FOR
  UPDATE` is not enough on its own. If the row was already loaded into
  the session earlier in the same request (e.g. by the lazy
  `get_or_create_wallet` lookup that runs just before the locking
  select), SQLAlchemy's identity map hands back the *already-loaded*
  Python object rather than refreshing it from the new, lock-guaranteed-
  current query — silently reintroducing the exact lost-update race the
  lock was supposed to prevent. Both `WalletRepository.get_for_update`
  and `EscrowRepository.get_for_update` pass
  `execution_options(populate_existing=True)` specifically to force that
  refresh. This was caught by testing genuine concurrency (ten parallel
  deposits landing on £10 instead of £100), not by code review — a good
  reminder that locking correctness needs a concurrency test, not just a
  unit test of the happy path.
- **A second async-ORM gotcha, same phase:** `Escrow.updated_at`
  (`onupdate=func.now()`) is left *expired* after a second UPDATE within
  the same session — e.g. `EscrowStateMachine` flushing a status change
  after the row's initial INSERT already happened. Touching `.updated_at`
  afterwards (a Pydantic response schema serializing the entity) then
  triggers an implicit lazy-reload, which fails outside an explicit
  `await` on an async session (`MissingGreenlet`). Fixed once, at the
  root, by setting `eager_defaults=True` on `TimestampMixin` and
  `CreatedAtMixin` (`app/database/base.py`) so every entity always fetches
  server-computed columns via `RETURNING` on flush, rather than patching
  each call site that happens to read a timestamp after a second write.
- Idempotency keys are required on financial POST endpoints. Phase 4's
  wallet deposit/withdraw enforce this via the unique constraint already
  on `WalletTransaction.idempotency_key` (Phase 2). Phase 6's
  `EscrowTransactionEngine` (fund/release/refund) follows the same
  pattern but checks `EscrowTransaction.idempotency_key` instead, since
  `release` touches two wallets' ledgers but produces only one
  `EscrowTransaction` — the single record of "did this already happen."
  A replayed request hits a database conflict, which the service catches
  and turns into "return the original result" rather than an error.
- **A third bug, same phase, same lesson as the first two:** money must
  never move before the state transition it depends on is validated. An
  early draft of `EscrowTransactionEngine.refund` decremented
  `held_balance` *then* called `EscrowStateMachine.transition` — so
  refunding an already-`RELEASED` escrow (a state with no legal path to
  `REFUNDED`) still executed a wallet `UPDATE` that tried to send
  `held_balance` negative. Postgres's own CHECK constraint caught it, but
  as an opaque `IntegrityError` from deep inside a flush, not the clean
  `InvalidStateTransitionError` this should have been. Fixed by
  validating (and applying, in-memory) the state transition *first* in
  every method — `fund`, `release`, `refund` — before any wallet is even
  locked. If anything fails afterward (insufficient funds, say), the
  `UnitOfWork` rolls back and discards the in-memory status change along
  with everything else, so the ordering costs nothing when the operation
  succeeds and fails cleanly when it doesn't.
- Escrow release/refund is guarded so a given escrow can only ever be
  released or refunded once — enforced both at the state-machine level
  and with a unique constraint at the database level as a second line of
  defence.
- `release` is the only operation that locks two different wallets in
  one transaction (debiting the payer, crediting the payee). Both are
  always locked in a fixed order — sorted by wallet ID, regardless of
  which one is "payer" or "payee" for that particular escrow — so two
  concurrent releases involving the same two users with payer/payee
  reversed (escrow A: Alice pays Bob; escrow B: Bob pays Alice) can never
  lock in opposite orders and deadlock. Verified with a test that
  actually creates that exact scenario and releases both concurrently.

## Dispute resolution

`DisputeService` (Phase 7) handles raising a dispute, submitting
evidence, and an admin resolving it. Resolution has three possible
outcomes (`DisputeResolution`, Phase 2):

- **RELEASE_TO_PAYEE** / **REFUND_TO_PAYER** — these reuse
  `EscrowTransactionEngine.release`/`refund` directly (Phase 6 already
  built admin-authorized paths from `DISPUTED` for exactly this).
- **SPLIT** — divides the escrow's held funds between both parties.
  `EscrowTransactionEngine.split` (Phase 7) is admin-only, requires the
  escrow to genuinely be `DISPUTED`, and requires `release_amount`
  strictly between 0 and the full amount (the full-amount edge cases
  already have `release`/`refund` — a split implies genuinely splitting).
  The payee receives `release_amount`; the remainder simply stays with
  the payer, since — same authorization-hold model as everywhere else in
  this codebase — it was never actually moved anywhere. The escrow lands
  on `RELEASED` regardless of the split ratio, mirroring the choice that
  a plain `release` also ends on `RELEASED` no matter the amount.

**A deliberate two-transaction trade-off.** `resolve_dispute` performs
the money movement (via the engine) and the `Dispute` row's own status
update as two separate commits, not one atomic transaction. This is a
conscious choice: `EscrowTransactionEngine`'s methods are already
self-contained, atomic, and idempotency-safe on their own. Threading an
externally-owned `UnitOfWork` through that already-shipped, already-
tested code so a caller could fold its own writes into the same commit
would add real complexity for a small risk — the `Dispute` update that
follows is a handful of scalar column assignments with no numeric
constraints or lock contention, overwhelmingly unlikely to fail right
after a successful money movement. If it ever did, it's safely
retryable: the escrow's own terminal status (already committed)
naturally prevents re-running the financial half, since
`EscrowStateMachine` rejects re-transitioning an already-terminal escrow.

## Security model

- **AuthN:** JWT access tokens (15 min default, `app.security.jwt`) issued
  alongside opaque, hashed, individually-revocable refresh tokens
  (`app.security.refresh_tokens`) with rotation on every `/auth/refresh`
  call — a refresh token can only ever be used once. Passwords are hashed
  with Argon2id (`app.security.password`). API keys follow the same
  hash-only-storage pattern (`app.security.api_keys`) for server-to-server
  integration.
- **AuthZ:** `get_current_user` (`app.security.dependencies`) accepts
  either an `X-API-Key` header or a `Authorization: Bearer <jwt>` header,
  so the same protected endpoint serves both interactive users and
  integrating backends. `require_role(*roles)` layers RBAC on top for
  admin-only routes (landing with dispute resolution in Phase 7).
- **Rate limiting:** a Redis-backed fixed-window limiter
  (`app.middleware.rate_limit`) applied per-endpoint — 5/min on register,
  10/min on login — rather than as blanket middleware, since brute-force
  risk varies by endpoint.
- **Secure headers:** `X-Content-Type-Options`, `X-Frame-Options`,
  `Referrer-Policy` on every response; HSTS added only when
  `ENVIRONMENT=production`.
- **CSRF:** deliberately not implemented. CSRF is a threat against
  cookie-based session auth, where a browser attaches credentials to a
  request automatically; this API's auth (JWT Bearer header / API key
  header) is never attached by a browser automatically, so there's no
  ambient credential for a forged cross-site request to ride on. Building
  CSRF protection for a threat model that doesn't apply here would just
  be complexity without a corresponding control.
- **OAuth-ready:** third-party OAuth login isn't implemented (nothing in
  the spec calls for a specific provider), but the shape is ready for it —
  `AuthService._issue_tokens` is the single chokepoint that turns "we've
  verified who this is" into an access/refresh token pair. An OAuth login
  flow would plug in as another way to reach that method, not a parallel
  token system.
- **Idempotency keys + replay protection** for financial endpoints land in
  Phase 6 (the `idempotency_key` columns already exist on
  `WalletTransaction` and `EscrowTransaction` from Phase 2, ready for it).

## Background workers

Four Celery tasks (Phase 8), each following the same shape: a plain
`async def _impl(...)` function holding the real logic, directly testable
with pytest-asyncio against a real database, and a thin
`@celery_app.task` sync wrapper that bridges into it via `asyncio.run`.
The wrapper is never called directly in tests — `asyncio.run` can't be
invoked from inside an already-running event loop, which pytest-asyncio
provides — so every test exercises the `_impl` function instead, and the
wrapper itself is verified separately by actually running a Celery worker
against Redis and dispatching a task through it.

- **Notification delivery** (`notifications.deliver_pending`, every
  minute) — picks up `PENDING` `Notification` rows (written since Phase 7
  by `notification_helpers.notify`) and delivers them via a pluggable
  `EmailSender`. No email provider is specified anywhere in this
  project's tech stack, so `EmailSender` is a `Protocol` with a
  `LoggingEmailSender` default — honest about not being wired to a real
  provider, rather than pretending to send mail that never arrives.
  Swapping in SendGrid/SES/SMTP later means implementing the protocol and
  changing one factory function; no call site elsewhere changes.
- **Expired-escrow detection** (`escrows.detect_expired`, hourly) —
  cancels escrows past an optional `expires_at` deadline (a Phase 2
  column that had never actually been set by anything until this phase
  wired it into `POST /escrows`) while still unfunded (`CREATED` /
  `AWAITING_PAYMENT`). Deliberately scoped to pre-funding states only —
  auto-resolving an expired deadline once money is actually held would
  mean fabricating a financial policy (auto-release? auto-refund?) that
  nothing in the spec calls for.
- **Daily wallet reconciliation** (`reconciliation.daily_wallet_reconciliation`,
  02:00 UTC) — see below.
- **Platform statistics** (`statistics.generate_platform_statistics`,
  01:00 UTC) — computes basic aggregate metrics (user count, escrow
  counts by status, total released volume, total wallet balance) and
  logs them. Deliberately lightweight: no new table persists historical
  snapshots yet — what history to keep, at what granularity, is a
  genuine reporting design decision that belongs with Phase 9, not
  bolted on here.

### Wallet reconciliation, in detail

Reconciliation checks two independent invariants per wallet, and getting
the first one right required correcting a documentation bug from Phase 6
first (see `WalletTransactionType`'s docstring, `app/domain/entities/enums.py`):
an earlier version claimed `amount` on `ESCROW_HOLD`/`ESCROW_REFUND`
entries was "the signed change to `held_balance`" — backwards from what
the code actually does. `amount` tracks the change to *available*
(non-held) funds instead: negative for a hold (funds become encumbered),
positive for a refund (the hold releases). This wasn't a functional bug —
nothing had summed the ledger before this task needed to — but it would
have produced a reconciliation check that was confidently wrong in
exactly the way a documentation/implementation mismatch does.

1. **Balance**: summing `WalletTransaction.amount` for the types that
   actually move `balance` (`DEPOSIT`, `WITHDRAWAL`, `ESCROW_RELEASE`)
   must equal the wallet's current `balance`. This is fully and correctly
   derivable from the ledger alone.
2. **Held balance**: summing the `amount` of escrows currently in a
   funds-held status (`FUNDED`, `IN_PROGRESS`, `AWAITING_APPROVAL`,
   `DISPUTED`) where the wallet's owner is the payer must equal
   `held_balance`. This is checked against *live escrow state*, not the
   ledger — deliberately. A payer-side `ESCROW_RELEASE` entry conflates a
   balance decrease and a held-balance decrease into one signed `amount`
   column; the schema can't cleanly separate them for a ledger-only
   reconstruction. Escrow status sidesteps the problem entirely rather
   than working around a ledger-schema limitation with something fragile.

Mismatches are logged and written as an `AuditLog` entry
(`WALLET_RECONCILIATION_MISMATCH`) — never raised as exceptions. A
reconciliation job's role is to surface problems for a human to
investigate, not to crash the worker or silently "fix" a balance itself.

## Observability

- **Structured logs** (`structlog`) — every log line carries a
  `request_id`, and financial operations additionally carry `escrow_id` /
  `wallet_id`, via `contextvars`.
- **Metrics** (`prometheus-client`) — request latency/count, escrow state
  transition counts, transaction engine error rates.
- **Tracing** (`OpenTelemetry`) — end-to-end spans across the API →
  service → repository → Celery task boundary.
- **Probes** — `/health` (liveness), `/health/live`, `/health/ready`
  (checks DB connectivity) for orchestrator integration.

## Build phases

See the [README](../README.md#build-phases) for the phase list. Each
phase's code lands with its own explanation and leaves the project
runnable before the next phase begins — this document is updated as new
architectural decisions are made along the way.
