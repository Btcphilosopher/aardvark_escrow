"""Domain event infrastructure.

A DomainEvent is an immutable record of something that happened inside
the domain — EscrowFunded, EscrowReleased, DisputeOpened, and so on.
Phase 5/6 add the concrete event types plus an in-process event bus (and
an outbox table so events survive a crash between commit and dispatch).
"""
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime


@dataclass(frozen=True)
class DomainEvent:
    """Base class every concrete domain event inherits from."""

    event_id: uuid.UUID = field(default_factory=uuid.uuid4)
    occurred_at: datetime = field(default_factory=lambda: datetime.now(UTC))
