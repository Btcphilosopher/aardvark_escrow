"""Domain-level exception hierarchy.

Domain and service code raises these — never `fastapi.HTTPException` — so
the domain layer stays framework-agnostic and testable in isolation. The
exception handlers registered in `app.main` translate them into HTTP
responses at the boundary.
"""


class AardvarkError(Exception):
    """Base class for every application-specific error."""


class DomainError(AardvarkError):
    """Raised when a domain invariant is violated."""


class InvalidStateTransitionError(DomainError):
    """Raised when an entity is asked to move to an illegal state.

    Used throughout the escrow state machine (Phase 5/6) to guarantee that
    only the transitions defined by the business rules can ever occur.
    """

    def __init__(self, entity: str, current_state: str, attempted_state: str) -> None:
        self.entity = entity
        self.current_state = current_state
        self.attempted_state = attempted_state
        super().__init__(
            f"{entity} cannot transition from '{current_state}' to '{attempted_state}'"
        )


class InsufficientFundsError(DomainError):
    """Raised when a wallet lacks sufficient balance for an operation."""


class NotFoundError(AardvarkError):
    """Raised when a requested resource does not exist."""


class AuthenticationError(AardvarkError):
    """Raised when authentication fails (bad credentials, expired token, ...)."""


class AuthorizationError(AardvarkError):
    """Raised when an authenticated principal lacks permission for an action."""


class ConflictError(AardvarkError):
    """Raised when an operation conflicts with the current resource state."""


class IdempotencyError(AardvarkError):
    """Raised when an idempotency key is replayed with a different payload."""


class RateLimitExceededError(AardvarkError):
    """Raised when a caller exceeds the allowed request rate."""
