"""Notification response schema."""
from datetime import datetime
from uuid import UUID

from app.domain.entities.enums import NotificationStatus, NotificationType
from app.schemas.base import ORMModel


class NotificationPublic(ORMModel):
    id: UUID
    type: NotificationType
    status: NotificationStatus
    title: str
    message: str
    reference_type: str | None
    reference_id: UUID | None
    read_at: datetime | None
    created_at: datetime
