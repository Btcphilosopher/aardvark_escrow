"""Dispute request/response schemas."""
from datetime import datetime
from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, Field, model_validator

from app.domain.entities.enums import DisputeResolution, DisputeStatus
from app.schemas.base import ORMModel


class RaiseDisputeRequest(BaseModel):
    reason: str = Field(min_length=1, max_length=2000)


class SubmitEvidenceRequest(BaseModel):
    description: str = Field(min_length=1, max_length=2000)
    file_url: str | None = Field(default=None, max_length=2048)
    file_hash: str | None = Field(default=None, max_length=128)


class ResolveDisputeRequest(BaseModel):
    resolution: DisputeResolution
    resolution_notes: str | None = Field(default=None, max_length=2000)
    release_amount: Decimal | None = Field(
        default=None, gt=0, max_digits=18, decimal_places=2
    )

    @model_validator(mode="after")
    def _release_amount_matches_resolution(self) -> "ResolveDisputeRequest":
        if self.resolution == DisputeResolution.SPLIT and self.release_amount is None:
            raise ValueError("release_amount is required when resolution is 'split'")
        if self.resolution != DisputeResolution.SPLIT and self.release_amount is not None:
            raise ValueError("release_amount is only used when resolution is 'split'")
        return self


class DisputePublic(ORMModel):
    id: UUID
    escrow_id: UUID
    raised_by_id: UUID
    status: DisputeStatus
    reason: str
    resolution: DisputeResolution | None
    resolution_notes: str | None
    resolved_by_id: UUID | None
    resolved_at: datetime | None
    created_at: datetime
    updated_at: datetime


class EvidencePublic(ORMModel):
    id: UUID
    dispute_id: UUID
    submitted_by_id: UUID
    description: str
    file_url: str | None
    file_hash: str | None
    created_at: datetime
