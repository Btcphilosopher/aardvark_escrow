"""Audit log response schema."""
from datetime import datetime
from typing import Any
from uuid import UUID

from app.schemas.base import ORMModel


class AuditLogPublic(ORMModel):
    id: UUID
    actor_id: UUID | None
    action: str
    resource_type: str
    resource_id: UUID | None
    extra_data: dict[str, Any] | None
    ip_address: str | None
    user_agent: str | None
    created_at: datetime
