"""Audit reporting.

The audit *trail itself* (writing `AuditLog` rows) has been live since
Phase 3 — every domain service writes one alongside its other work via
`AuditLogRepository`. `GET /audit` (Phase 7) reads them back directly
through that repository; there's little enough logic there ("list
recent, admin only") that a dedicated service isn't warranted.

This package is reserved for actual reporting on top of that trail —
PDF/CSV exports, financial summaries, operator activity reports — which
lands in Phase 9 alongside the rest of the reporting story.
"""
