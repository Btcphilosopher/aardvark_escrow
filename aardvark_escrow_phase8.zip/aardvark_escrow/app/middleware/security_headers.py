"""Secure response headers, applied to every response.

A conservative baseline: prevents MIME-sniffing, blocks the app from
being framed (clickjacking), and avoids leaking the full referrer to
third parties. HSTS is only sent in production — sending it over plain
HTTP in local dev would make browsers force HTTPS for localhost, which
is not what anyone running `docker compose up` wants.
"""
from collections.abc import Awaitable, Callable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from app.core.config import settings


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self, request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        if settings.is_production:
            response.headers["Strict-Transport-Security"] = (
                "max-age=63072000; includeSubDomains"
            )
        return response
