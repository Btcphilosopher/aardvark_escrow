"""Small helper for services to create in-app notifications alongside
their other writes, without every call site re-importing and
hand-constructing `Notification`.

This only creates the DB row -- the "you have a notification" record.
Actual delivery (email, push, ...) is Phase 8's background workers, which
will read PENDING notifications and update their status once sent.
"""
from uuid import UUID

from app.database.unit_of_work import UnitOfWork
from app.domain.entities.enums import NotificationType
from app.domain.entities.notification import Notification


def notify(
    uow: UnitOfWork,
    user_id: UUID,
    notification_type: NotificationType,
    *,
    title: str,
    message: str,
    reference_type: str | None = None,
    reference_id: UUID | None = None,
) -> None:
    uow.notifications.add(
        Notification(
            user_id=user_id,
            type=notification_type,
            title=title,
            message=message,
            reference_type=reference_type,
            reference_id=reference_id,
        )
    )
