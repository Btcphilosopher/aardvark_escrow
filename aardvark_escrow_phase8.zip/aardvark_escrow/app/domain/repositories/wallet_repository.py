"""Wallet persistence.

`get_for_update` takes a `SELECT ... FOR UPDATE` row lock — the mechanism
`WalletService` (Phase 4) and the Phase 6 escrow transaction engine both
rely on to serialise concurrent operations against the same wallet and
prevent double-spending. It's introduced here, alongside the model,
rather than bolted on later, so the locking story is settled before any
business logic depends on it.
"""
from typing import Protocol
from uuid import UUID

from sqlalchemy import select

from app.domain.entities.wallet import Wallet, WalletTransaction
from app.domain.repositories.base import SQLAlchemyRepository


class WalletRepository(Protocol):
    async def get_by_id(self, wallet_id: UUID) -> Wallet | None: ...
    async def get_by_user_id(self, user_id: UUID) -> Wallet | None: ...
    async def get_for_update(self, wallet_id: UUID) -> Wallet | None: ...
    async def get_transaction_by_idempotency_key(
        self, idempotency_key: str
    ) -> WalletTransaction | None: ...
    def add(self, wallet: Wallet) -> None: ...


class SQLAlchemyWalletRepository(SQLAlchemyRepository[Wallet]):
    model = Wallet

    async def get_by_user_id(self, user_id: UUID) -> Wallet | None:
        result = await self._session.execute(
            select(Wallet).where(Wallet.user_id == user_id)
        )
        return result.scalar_one_or_none()

    async def get_for_update(self, wallet_id: UUID) -> Wallet | None:
        """Lock the wallet row for the duration of the current transaction.

        Callers must be inside an explicit transaction (i.e. not autocommit)
        for the lock to have any effect — see `app.database.unit_of_work`.

        `populate_existing=True` matters here and is not just belt-and-
        braces: if this `Wallet` is already in the session's identity map
        (e.g. `get_or_create_wallet` just loaded it moments earlier),
        SQLAlchemy's default behaviour is to hand back that cached Python
        object as-is rather than refresh it from this query's result —
        even though the SQL sent genuinely includes `FOR UPDATE` and
        genuinely blocks until the lock is free. Without this option,
        every caller would read the *pre-lock* balance instead of the
        fresh, lock-guaranteed-current one, silently reintroducing the
        exact lost-update race this method exists to prevent.
        """
        result = await self._session.execute(
            select(Wallet)
            .where(Wallet.id == wallet_id)
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        return result.scalar_one_or_none()

    async def get_transaction_by_idempotency_key(
        self, idempotency_key: str
    ) -> WalletTransaction | None:
        """Look up a previously-processed deposit/withdraw by its key.

        Used to turn a replayed request (one that hits the unique
        constraint on `WalletTransaction.idempotency_key`) into "return
        the original result" instead of an error.
        """
        result = await self._session.execute(
            select(WalletTransaction).where(
                WalletTransaction.idempotency_key == idempotency_key
            )
        )
        return result.scalar_one_or_none()
