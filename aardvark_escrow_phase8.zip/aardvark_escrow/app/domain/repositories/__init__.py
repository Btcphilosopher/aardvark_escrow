"""Repository interfaces and their SQLAlchemy implementations.

Each module pairs a `Protocol` (the interface the service layer depends
on) with a `SQLAlchemy*Repository` (the concrete implementation wired up
via dependency injection). Re-exported here for convenient importing.
"""
from app.domain.repositories.api_key_repository import (
    APIKeyRepository,
    SQLAlchemyAPIKeyRepository,
)
from app.domain.repositories.audit_log_repository import (
    AuditLogRepository,
    SQLAlchemyAuditLogRepository,
)
from app.domain.repositories.dispute_repository import (
    DisputeRepository,
    SQLAlchemyDisputeRepository,
)
from app.domain.repositories.escrow_repository import (
    EscrowRepository,
    SQLAlchemyEscrowRepository,
)
from app.domain.repositories.notification_repository import (
    NotificationRepository,
    SQLAlchemyNotificationRepository,
)
from app.domain.repositories.refresh_token_repository import (
    RefreshTokenRepository,
    SQLAlchemyRefreshTokenRepository,
)
from app.domain.repositories.user_repository import SQLAlchemyUserRepository, UserRepository
from app.domain.repositories.wallet_repository import (
    SQLAlchemyWalletRepository,
    WalletRepository,
)

__all__ = [
    "APIKeyRepository",
    "AuditLogRepository",
    "DisputeRepository",
    "EscrowRepository",
    "NotificationRepository",
    "RefreshTokenRepository",
    "SQLAlchemyAPIKeyRepository",
    "SQLAlchemyAuditLogRepository",
    "SQLAlchemyDisputeRepository",
    "SQLAlchemyEscrowRepository",
    "SQLAlchemyNotificationRepository",
    "SQLAlchemyRefreshTokenRepository",
    "SQLAlchemyUserRepository",
    "SQLAlchemyWalletRepository",
    "UserRepository",
    "WalletRepository",
]
