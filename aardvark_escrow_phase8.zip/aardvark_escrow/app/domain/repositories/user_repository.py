"""User persistence.

`UserRepository` is the interface the service layer depends on — a test
can satisfy it with an in-memory fake without touching Postgres.
`SQLAlchemyUserRepository` is the concrete implementation wired up at
runtime via dependency injection (Phase 3/4).
"""
from typing import Protocol
from uuid import UUID

from sqlalchemy import select

from app.domain.entities.user import User
from app.domain.repositories.base import SQLAlchemyRepository


class UserRepository(Protocol):
    async def get_by_id(self, user_id: UUID) -> User | None: ...
    async def get_by_email(self, email: str) -> User | None: ...
    def add(self, user: User) -> None: ...


class SQLAlchemyUserRepository(SQLAlchemyRepository[User]):
    model = User

    async def get_by_email(self, email: str) -> User | None:
        result = await self._session.execute(
            select(User).where(User.email == email.lower())
        )
        return result.scalar_one_or_none()
