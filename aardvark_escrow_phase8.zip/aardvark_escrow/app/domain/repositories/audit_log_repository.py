"""AuditLog persistence.

Deliberately exposes no update or delete method at all — not "unused",
genuinely absent — so the immutability guarantee is enforced by the type
the service layer depends on, not just by convention.
"""
from typing import Protocol
from uuid import UUID

from sqlalchemy import select

from app.domain.entities.audit import AuditLog
from app.domain.repositories.base import SQLAlchemyRepository


class AuditLogRepository(Protocol):
    async def list_by_resource(
        self, resource_type: str, resource_id: UUID, limit: int = 100
    ) -> list[AuditLog]: ...
    async def list_recent(self, limit: int = 100, offset: int = 0) -> list[AuditLog]: ...
    def add(self, audit_log: AuditLog) -> None: ...


class SQLAlchemyAuditLogRepository(SQLAlchemyRepository[AuditLog]):
    model = AuditLog

    async def list_by_resource(
        self, resource_type: str, resource_id: UUID, limit: int = 100
    ) -> list[AuditLog]:
        result = await self._session.execute(
            select(AuditLog)
            .where(
                AuditLog.resource_type == resource_type,
                AuditLog.resource_id == resource_id,
            )
            .order_by(AuditLog.created_at.desc())
            .limit(limit)
        )
        return list(result.scalars().all())

    async def list_recent(self, limit: int = 100, offset: int = 0) -> list[AuditLog]:
        result = await self._session.execute(
            select(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit).offset(offset)
        )
        return list(result.scalars().all())
