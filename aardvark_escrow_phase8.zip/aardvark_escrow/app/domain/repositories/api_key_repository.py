"""APIKey persistence."""
from typing import Protocol
from uuid import UUID

from sqlalchemy import select

from app.domain.entities.api_key import APIKey
from app.domain.repositories.base import SQLAlchemyRepository


class APIKeyRepository(Protocol):
    async def get_by_id(self, api_key_id: UUID) -> APIKey | None: ...
    async def get_by_hashed_key(self, hashed_key: str) -> APIKey | None: ...
    async def list_for_user(self, user_id: UUID) -> list[APIKey]: ...
    def add(self, api_key: APIKey) -> None: ...


class SQLAlchemyAPIKeyRepository(SQLAlchemyRepository[APIKey]):
    model = APIKey

    async def get_by_hashed_key(self, hashed_key: str) -> APIKey | None:
        result = await self._session.execute(
            select(APIKey).where(APIKey.hashed_key == hashed_key)
        )
        return result.scalar_one_or_none()

    async def list_for_user(self, user_id: UUID) -> list[APIKey]:
        result = await self._session.execute(
            select(APIKey)
            .where(APIKey.user_id == user_id)
            .order_by(APIKey.created_at.desc())
        )
        return list(result.scalars().all())
