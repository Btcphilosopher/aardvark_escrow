"""Domain entities.

Every entity module is imported here so that importing `app.domain.entities`
(as `migrations/env.py` does) is sufficient to register all mapped classes
against `Base.metadata` — required for Alembic autogenerate to see the
full schema.
"""
from app.domain.entities.api_key import APIKey
from app.domain.entities.audit import AuditAction, AuditLog
from app.domain.entities.dispute import Dispute, Evidence
from app.domain.entities.enums import (
    APIKeyStatus,
    DisputeResolution,
    DisputeStatus,
    EscrowStatus,
    EscrowTransactionStatus,
    EscrowTransactionType,
    NotificationStatus,
    NotificationType,
    UserRole,
    UserStatus,
    WalletTransactionType,
)
from app.domain.entities.escrow import Escrow, EscrowEvent, EscrowTransaction
from app.domain.entities.notification import Notification
from app.domain.entities.refresh_token import RefreshToken
from app.domain.entities.user import User
from app.domain.entities.wallet import Wallet, WalletTransaction

__all__ = [
    "APIKey",
    "APIKeyStatus",
    "AuditAction",
    "AuditLog",
    "Dispute",
    "DisputeResolution",
    "DisputeStatus",
    "Escrow",
    "EscrowEvent",
    "EscrowStatus",
    "EscrowTransaction",
    "EscrowTransactionStatus",
    "EscrowTransactionType",
    "Evidence",
    "Notification",
    "NotificationStatus",
    "NotificationType",
    "RefreshToken",
    "User",
    "UserRole",
    "UserStatus",
    "Wallet",
    "WalletTransaction",
    "WalletTransactionType",
]
