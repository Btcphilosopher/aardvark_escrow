"""AuditLog entity.

Every security- or money-relevant action in the system writes one of
these rows: login, escrow creation, funding, approval, release, refund,
dispute lifecycle, settings changes, admin actions. Audit rows are
append-only by design — there is no update or delete path anywhere in
this codebase for `AuditLog`, and that invariant must never change.

`action` is a plain indexed string rather than a database enum
deliberately: new action types will keep being added as later phases
land, and a DB enum would mean a migration for each one. `AuditAction`
below is the canonical, typo-proof registry of values used at the
Python level instead.
"""
from typing import TYPE_CHECKING, Any
from uuid import UUID

from sqlalchemy import ForeignKey, Index, String, Uuid
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, CreatedAtMixin, UUIDPrimaryKeyMixin

if TYPE_CHECKING:
    from app.domain.entities.user import User


class AuditAction:
    """Canonical audit action names. Extend freely — no migration needed."""

    USER_REGISTERED = "user.registered"
    USER_LOGIN = "user.login"
    USER_LOGIN_FAILED = "user.login_failed"
    USER_LOGOUT = "user.logout"
    USER_UPDATED = "user.updated"

    WALLET_DEPOSITED = "wallet.deposited"
    WALLET_WITHDRAWN = "wallet.withdrawn"

    ESCROW_CREATED = "escrow.created"
    ESCROW_FUNDED = "escrow.funded"
    ESCROW_APPROVED = "escrow.approved"
    ESCROW_RELEASED = "escrow.released"
    ESCROW_REFUNDED = "escrow.refunded"
    ESCROW_CANCELLED = "escrow.cancelled"

    DISPUTE_OPENED = "dispute.opened"
    DISPUTE_EVIDENCE_SUBMITTED = "dispute.evidence_submitted"
    DISPUTE_RESOLVED = "dispute.resolved"

    API_KEY_CREATED = "api_key.created"
    API_KEY_REVOKED = "api_key.revoked"

    ADMIN_ACTION = "admin.action"
    SETTINGS_CHANGED = "settings.changed"

    WALLET_RECONCILIATION_MISMATCH = "wallet.reconciliation_mismatch"


class AuditLog(Base, UUIDPrimaryKeyMixin, CreatedAtMixin):
    __tablename__ = "audit_logs"
    __table_args__ = (
        Index("ix_audit_logs_resource_type_resource_id", "resource_type", "resource_id"),
        Index("ix_audit_logs_actor_id_created_at", "actor_id", "created_at"),
    )

    actor_id: Mapped[UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    action: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    resource_type: Mapped[str] = mapped_column(String(50), nullable=False)
    resource_id: Mapped[UUID | None] = mapped_column(Uuid, nullable=True)

    extra_data: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)
    ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(512), nullable=True)

    actor: Mapped["User | None"] = relationship(
        back_populates="audit_logs", foreign_keys=[actor_id]
    )

    def __repr__(self) -> str:  # pragma: no cover - debugging aid only
        return (
            f"<AuditLog id={self.id} action={self.action!r} "
            f"resource_type={self.resource_type!r}>"
        )
