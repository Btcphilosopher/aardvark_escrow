"""Email sending abstraction.

No email provider (SendGrid, SES, SMTP, ...) is specified anywhere in
this project's tech stack, so this defines the interface a real one
would implement, backed by a logging-only default that's safe to run
anywhere — including this sandbox — without misconfiguring outbound
mail. Swapping in a real provider means implementing `EmailSender` and
changing `get_email_sender()`; no call site elsewhere changes.
"""
from typing import Protocol

import structlog

logger = structlog.get_logger(__name__)


class EmailSender(Protocol):
    def send(self, *, to: str, subject: str, body: str) -> None: ...


class LoggingEmailSender:
    """Logs what would be sent instead of actually sending anything.

    The correct default for local development and for this sandbox —
    honest about the fact that no real provider is wired in, rather than
    silently pretending to send email that never arrives.
    """

    def send(self, *, to: str, subject: str, body: str) -> None:
        logger.info("email_would_be_sent", to=to, subject=subject, body=body)


def get_email_sender() -> EmailSender:
    return LoggingEmailSender()
