"""API key generation and hashing.

Mirrors the refresh token approach: only a hash is ever persisted. The
`key_prefix` returned alongside the raw key is non-secret and safe to
display back to the user afterwards so they can tell keys apart in a
list — the pattern Stripe and GitHub both use for their API keys.

Note: this module provides the crypto primitives only. No CRUD endpoint
for creating/listing/revoking API keys exists yet — that wasn't in the
original endpoint list, so it's deferred to a later phase. What's here is
enough for `get_current_user` (app.security.dependencies) to already
accept an `X-API-Key` header today.
"""
import hashlib
import secrets

_KEY_BYTES = 32
_KEY_PREFIX_TAG = "ae_live_"


def generate_api_key() -> tuple[str, str]:
    """Returns `(raw_key, key_prefix)`. Persist only `hash_api_key(raw_key)`."""
    raw_key = f"{_KEY_PREFIX_TAG}{secrets.token_urlsafe(_KEY_BYTES)}"
    key_prefix = raw_key[: len(_KEY_PREFIX_TAG) + 6]
    return raw_key, key_prefix


def hash_api_key(raw_key: str) -> str:
    return hashlib.sha256(raw_key.encode("utf-8")).hexdigest()
