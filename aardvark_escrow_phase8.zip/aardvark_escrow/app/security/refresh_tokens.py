"""Opaque refresh token generation and hashing.

Refresh tokens are high-entropy random strings, not JWTs: they carry no
information of their own, so the only way to use one is to present it
back to the server, which looks it up by hash. That's what makes them
individually revocable (Phase 3's logout sets `revoked_at`) — a JWT
refresh token would still verify as valid right up to its expiry no
matter what the database says, unless a denylist were maintained anyway,
at which point the JWT's self-contained-ness buys nothing.

The hash used here is SHA-256, not Argon2: the raw token already has
~340 bits of entropy from `secrets.token_urlsafe`, so it needs no
memory-hard slow hashing to resist brute force — and refresh happens
often enough (every access-token expiry) that a slow hash would add real
latency for no security benefit.
"""
import hashlib
import secrets

_TOKEN_BYTES = 64


def generate_refresh_token() -> str:
    return secrets.token_urlsafe(_TOKEN_BYTES)


def hash_refresh_token(raw_token: str) -> str:
    return hashlib.sha256(raw_token.encode("utf-8")).hexdigest()
