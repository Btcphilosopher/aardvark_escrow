"""Wallet endpoints.

Wallets are provisioned lazily — see `app.domain.services.wallet_service`
for the reasoning and for the row-locking + ledger discipline behind
deposit/withdraw.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db
from app.domain.entities.user import User
from app.domain.services.wallet_service import WalletService
from app.schemas.wallet import DepositRequest, WalletPublic, WithdrawRequest
from app.security.dependencies import get_current_user

router = APIRouter(prefix="/wallet", tags=["wallet"])


@router.get("", response_model=WalletPublic)
async def get_wallet(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> WalletPublic:
    wallet = await WalletService(db).get_or_create_wallet(current_user.id)
    return WalletPublic.model_validate(wallet)


@router.post("/deposit", response_model=WalletPublic)
async def deposit(
    body: DepositRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> WalletPublic:
    wallet = await WalletService(db).deposit(
        current_user.id,
        amount=body.amount,
        description=body.description,
        idempotency_key=body.idempotency_key,
    )
    return WalletPublic.model_validate(wallet)


@router.post("/withdraw", response_model=WalletPublic)
async def withdraw(
    body: WithdrawRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> WalletPublic:
    wallet = await WalletService(db).withdraw(
        current_user.id,
        amount=body.amount,
        description=body.description,
        idempotency_key=body.idempotency_key,
    )
    return WalletPublic.model_validate(wallet)
