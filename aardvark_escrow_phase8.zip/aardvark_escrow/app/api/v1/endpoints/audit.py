"""Audit log endpoint.

Admin-only — the audit trail covers every user's activity, not just the
caller's own, so it isn't something a regular user should be able to
list. Pure read via the repository directly; no business logic beyond
"list recent, admin only" is needed, so there's no dedicated service.
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db
from app.domain.entities.enums import UserRole
from app.domain.repositories.audit_log_repository import SQLAlchemyAuditLogRepository
from app.schemas.audit import AuditLogPublic
from app.security.dependencies import require_role

router = APIRouter(prefix="/audit", tags=["audit"])


@router.get("", response_model=list[AuditLogPublic])
async def list_audit_logs(
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    _admin: object = Depends(require_role(UserRole.ADMIN)),
    db: AsyncSession = Depends(get_db),
) -> list[AuditLogPublic]:
    logs = await SQLAlchemyAuditLogRepository(db).list_recent(limit=limit, offset=offset)
    return [AuditLogPublic.model_validate(log) for log in logs]
