"""Notification endpoint — lists the current user's own notifications.

Notification *creation* happens as a side effect of the domain services
that already write one alongside their other work (escrow created,
funded, released, refunded, cancelled; disputes opened/resolved — see
`app.domain.services.notification_helpers`). There's no user-facing
"create notification" endpoint; this is a read-only view onto rows other
services produce. Actual external delivery (email, push) is Phase 8's
background workers, which will read PENDING notifications here and
update their status once sent.
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db
from app.domain.entities.user import User
from app.domain.repositories.notification_repository import SQLAlchemyNotificationRepository
from app.schemas.notification import NotificationPublic
from app.security.dependencies import get_current_user

router = APIRouter(prefix="/notifications", tags=["notifications"])


@router.get("", response_model=list[NotificationPublic])
async def list_notifications(
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[NotificationPublic]:
    notifications = await SQLAlchemyNotificationRepository(db).list_for_user(
        current_user.id, limit=limit, offset=offset
    )
    return [NotificationPublic.model_validate(n) for n in notifications]
