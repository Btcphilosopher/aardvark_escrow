"""Dispute endpoints: submit evidence, resolve.

Raising a dispute (`POST /escrows/{id}/dispute`) lives in `escrows.py`
since it's namespaced under an escrow; these two are namespaced under a
dispute directly.
"""
from uuid import UUID

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db
from app.domain.entities.user import User
from app.domain.services.dispute_service import DisputeService
from app.schemas.dispute import (
    DisputePublic,
    EvidencePublic,
    ResolveDisputeRequest,
    SubmitEvidenceRequest,
)
from app.security.dependencies import get_current_user

router = APIRouter(prefix="/disputes", tags=["disputes"])


@router.post("/{dispute_id}/evidence", response_model=EvidencePublic, status_code=201)
async def submit_evidence(
    dispute_id: UUID,
    body: SubmitEvidenceRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> EvidencePublic:
    evidence = await DisputeService(db).submit_evidence(
        dispute_id,
        current_user=current_user,
        description=body.description,
        file_url=body.file_url,
        file_hash=body.file_hash,
    )
    return EvidencePublic.model_validate(evidence)


@router.post("/{dispute_id}/resolve", response_model=DisputePublic)
async def resolve_dispute(
    dispute_id: UUID,
    body: ResolveDisputeRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> DisputePublic:
    dispute = await DisputeService(db).resolve_dispute(
        dispute_id,
        current_user=current_user,
        resolution=body.resolution,
        resolution_notes=body.resolution_notes,
        release_amount=body.release_amount,
    )
    return DisputePublic.model_validate(dispute)
