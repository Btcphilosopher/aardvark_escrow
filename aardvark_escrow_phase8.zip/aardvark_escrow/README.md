# Aardvark Escrow

A production-grade escrow platform: it holds funds between two or more
parties and releases, refunds, or arbitrates them according to strict,
auditable business rules. Built for marketplaces, procurement systems,
freelance platforms, and logistics companies that need a REST API they can
integrate against, not a spreadsheet with extra steps.

> **Status:** Phase 8 — background workers. Celery tasks for notification
> delivery, expired-escrow detection, daily wallet reconciliation, and
> platform statistics are all live, verified against real Postgres and a
> real Celery worker consuming from Redis. See
> [docs/architecture.md](docs/architecture.md) for the reconciliation
> design and the ledger-semantics fix it required.

## Stack

FastAPI · SQLAlchemy 2.x (async) · Alembic · PostgreSQL · Redis · Celery ·
Pydantic v2 · PyJWT · Passlib (Argon2) · Structlog · Prometheus ·
OpenTelemetry · ReportLab · Pytest · Docker

## Quickstart

```bash
cp .env.example .env
docker compose up --build
```

The API comes up on `http://localhost:8000`, with interactive docs at
`http://localhost:8000/api/v1/docs`.

Check it's alive:

```bash
curl http://localhost:8000/api/v1/health
curl http://localhost:8000/api/v1/health/ready   # verifies DB connectivity
```

## Local development without Docker

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env   # then point DATABASE_URL/REDIS_URL at local services
python main.py
```

Background workers (Phase 8) run as separate processes, both pointed at
the same `.env`:

```bash
celery -A app.workers.celery_app worker --loglevel=info   # runs tasks
celery -A app.workers.celery_app beat --loglevel=info     # triggers them on schedule
```

Run the test suite:

```bash
pytest --cov=app
```

The test suite is a real integration suite — it runs against Postgres and
Redis rather than mocking them (an escrow platform's entire value is
transactional correctness, so that's what needs testing). Before running
it: `docker compose up -d postgres redis`, apply migrations
(`alembic upgrade head`), and set `ENVIRONMENT=test` in `.env` — this
disables rate limiting so the test suite's rapid successive requests
don't trip it (the limiter's own logic is covered separately in
`tests/test_rate_limit.py`, which turns the gate back off for its own
assertions).

## Project layout

```
app/
  main.py            FastAPI application factory
  core/               settings, logging, exception hierarchy, redis client
  database/           async engine, session factory, declarative base,
                       UnitOfWork (Phase 4)
  domain/
    entities/          SQLAlchemy models (Phase 2) — 12 tables
    repositories/       persistence interfaces + SQLAlchemy impls (Phase 2)
    services/           AuthService (Phase 3); UserService, WalletService
                        (Phase 4); EscrowStateMachine, EscrowService
                        (Phase 5); EscrowTransactionEngine (Phase 6) —
                        fund/approve/release/refund/split;
                        DisputeService (Phase 7); notification_helpers
  events/              domain event base class + bus (future)
  security/            JWT, Argon2 hashing, refresh tokens, API keys,
                       get_current_user / require_role (Phase 3)
  schemas/             Pydantic request/response models
  middleware/          request context, rate limiting, security headers
  api/v1/              versioned REST endpoints — auth, users, wallet,
                       escrows, disputes, audit, notifications, health
  audit/               audit *reporting* on top of the trail (Phase 9);
                       the trail itself has been live since Phase 3
  notifications/       (docstring only — actual delivery logic lives in
                       app/workers/tasks/notifications.py, Phase 8; rows
                       have been created since Phase 7)
  workers/             Celery app + Beat schedule + tasks (Phase 8):
                       notification delivery, expired-escrow detection,
                       daily wallet reconciliation, platform statistics
migrations/           Alembic environment + versions
tests/                 pytest suite (unit + integration against real
                       Postgres/Redis)
docs/                  architecture, ER diagrams, guides
docker/                per-service Dockerfiles
scripts/               entrypoint / ops scripts
```

See [docs/architecture.md](docs/architecture.md) for the full design
rationale, the escrow state machine, and the phased build plan.

## Build phases

1. Project scaffolding and architecture
2. Database models and migrations
3. Authentication system
4. User and wallet services
5. Escrow domain model + state machine
6. Escrow transaction engine
7. REST API (escrows, disputes, audit, notifications)
8. Background workers ← you are here
9. Audit and reporting
10. Testing (target: 90% coverage)
11. Documentation

Each phase leaves the project in a runnable, tested state before the next
begins.
