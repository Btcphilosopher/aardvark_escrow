"""Integration tests for the dispute lifecycle: raise, submit evidence,
resolve (release_to_payee, refund_to_payer, split).
"""
from decimal import Decimal

import pytest
from httpx import AsyncClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import InvalidStateTransitionError
from app.domain.entities.enums import UserRole
from app.domain.entities.user import User
from app.domain.services.escrow_transaction_engine import EscrowTransactionEngine
from app.security.password import hash_password

PASSWORD = "correct-horse-42"


async def _register(client: AsyncClient, email: str, full_name: str = "Test User") -> dict:
    response = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": PASSWORD, "full_name": full_name},
    )
    body = response.json()
    return {"token": body["access_token"], "user_id": body["user"]["id"]}


def _headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


async def _deposit(client: AsyncClient, token: str, amount: str) -> None:
    response = await client.post(
        "/api/v1/wallet/deposit", headers=_headers(token), json={"amount": amount}
    )
    assert response.status_code == 200


async def _make_admin(db_session: AsyncSession, email: str, full_name: str = "Admin") -> dict:
    """Registers via the ORM directly with UserRole.ADMIN — there's no
    self-serve "become an admin" endpoint, nor should there be.
    """
    user = User(
        email=email,
        hashed_password=hash_password(PASSWORD),
        full_name=full_name,
        role=UserRole.ADMIN,
    )
    db_session.add(user)
    await db_session.commit()
    return {"email": email, "user_id": str(user.id)}


async def _login(client: AsyncClient, email: str) -> str:
    response = await client.post(
        "/api/v1/auth/login", json={"email": email, "password": PASSWORD}
    )
    return str(response.json()["access_token"])


async def _setup_disputed_escrow(client: AsyncClient, suffix: str, amount: str = "500.00"):
    payer = await _register(client, f"d-payer-{suffix}@example.com", "Payer")
    payee = await _register(client, f"d-payee-{suffix}@example.com", "Payee")
    await _deposit(client, payer["token"], "1000.00")

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": f"d-payee-{suffix}@example.com",
            "amount": amount,
            "description": "Disputed test escrow",
        },
    )
    escrow_id = create_response.json()["id"]
    await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer["token"]), json={}
    )

    dispute_response = await client.post(
        f"/api/v1/escrows/{escrow_id}/dispute",
        headers=_headers(payer["token"]),
        json={"reason": "Work not delivered as agreed"},
    )
    dispute_id = dispute_response.json()["id"]
    return payer, payee, escrow_id, dispute_id


# ------------------------------------------------------------- raise


async def test_raise_dispute_moves_escrow_to_disputed(client: AsyncClient) -> None:
    payer, payee, escrow_id, dispute_id = await _setup_disputed_escrow(client, "r1")

    escrow_response = await client.get(
        f"/api/v1/escrows/{escrow_id}", headers=_headers(payer["token"])
    )
    assert escrow_response.json()["status"] == "disputed"

    dispute_response = await client.get(
        "/api/v1/notifications", headers=_headers(payee["token"])
    )
    assert any(n["reference_id"] == dispute_id for n in dispute_response.json())


async def test_raise_dispute_requires_being_a_party(client: AsyncClient) -> None:
    payer = await _register(client, "d-payer-out@example.com", "Payer")
    await _register(client, "d-payee-out@example.com", "Payee")
    outsider = await _register(client, "d-outsider@example.com", "Outsider")
    await _deposit(client, payer["token"], "1000.00")

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "d-payee-out@example.com",
            "amount": "100.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]
    await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer["token"]), json={}
    )

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/dispute",
        headers=_headers(outsider["token"]),
        json={"reason": "not my business"},
    )
    assert response.status_code == 404


async def test_cannot_dispute_an_unfunded_escrow(client: AsyncClient) -> None:
    payer = await _register(client, "d-payer-unfunded@example.com", "Payer")
    await _register(client, "d-payee-unfunded@example.com", "Payee")

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "d-payee-unfunded@example.com",
            "amount": "100.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/dispute",
        headers=_headers(payer["token"]),
        json={"reason": "too early"},
    )
    assert response.status_code == 422


# ------------------------------------------------------------ evidence


async def test_submit_evidence_by_either_party(client: AsyncClient) -> None:
    payer, payee, _escrow_id, dispute_id = await _setup_disputed_escrow(client, "e1")

    payer_evidence = await client.post(
        f"/api/v1/disputes/{dispute_id}/evidence",
        headers=_headers(payer["token"]),
        json={"description": "Screenshot of the missed deadline"},
    )
    payee_evidence = await client.post(
        f"/api/v1/disputes/{dispute_id}/evidence",
        headers=_headers(payee["token"]),
        json={"description": "Proof of delivery", "file_url": "https://example.com/proof.png"},
    )

    assert payer_evidence.status_code == 201
    assert payee_evidence.status_code == 201


async def test_submit_evidence_rejects_outsiders(client: AsyncClient) -> None:
    _payer, _payee, _escrow_id, dispute_id = await _setup_disputed_escrow(client, "e2")
    outsider = await _register(client, "d-outsider-e@example.com", "Outsider")

    response = await client.post(
        f"/api/v1/disputes/{dispute_id}/evidence",
        headers=_headers(outsider["token"]),
        json={"description": "not involved"},
    )
    assert response.status_code == 404


# ------------------------------------------------------------- resolve


async def test_resolve_requires_admin(client: AsyncClient) -> None:
    payer, _payee, _escrow_id, dispute_id = await _setup_disputed_escrow(client, "res1")

    response = await client.post(
        f"/api/v1/disputes/{dispute_id}/resolve",
        headers=_headers(payer["token"]),
        json={"resolution": "release_to_payee"},
    )
    assert response.status_code == 403


async def test_resolve_release_to_payee(client: AsyncClient, db_session: AsyncSession) -> None:
    payer, payee, escrow_id, dispute_id = await _setup_disputed_escrow(
        client, "res2", amount="300.00"
    )
    admin = await _make_admin(db_session, "admin-res2@example.com")
    admin_token = await _login(client, "admin-res2@example.com")

    response = await client.post(
        f"/api/v1/disputes/{dispute_id}/resolve",
        headers=_headers(admin_token),
        json={"resolution": "release_to_payee", "resolution_notes": "Payee delivered"},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "resolved"
    assert body["resolution"] == "release_to_payee"
    assert body["resolved_by_id"] == admin["user_id"]

    escrow_response = await client.get(
        f"/api/v1/escrows/{escrow_id}", headers=_headers(payer["token"])
    )
    assert escrow_response.json()["status"] == "released"

    payee_wallet = await client.get("/api/v1/wallet", headers=_headers(payee["token"]))
    assert payee_wallet.json()["balance"] == "300.00"


async def test_resolve_refund_to_payer(client: AsyncClient, db_session: AsyncSession) -> None:
    payer, _payee, escrow_id, dispute_id = await _setup_disputed_escrow(
        client, "res3", amount="250.00"
    )
    await _make_admin(db_session, "admin-res3@example.com")
    admin_token = await _login(client, "admin-res3@example.com")

    response = await client.post(
        f"/api/v1/disputes/{dispute_id}/resolve",
        headers=_headers(admin_token),
        json={"resolution": "refund_to_payer"},
    )
    assert response.status_code == 200
    assert response.json()["status"] == "resolved"
    assert response.json()["resolution"] == "refund_to_payer"

    escrow_response = await client.get(
        f"/api/v1/escrows/{escrow_id}", headers=_headers(payer["token"])
    )
    assert escrow_response.json()["status"] == "closed"

    payer_wallet = await client.get("/api/v1/wallet", headers=_headers(payer["token"]))
    assert payer_wallet.json()["balance"] == "1000.00"
    assert payer_wallet.json()["held_balance"] == "0.00"


async def test_resolve_split(client: AsyncClient, db_session: AsyncSession) -> None:
    payer, payee, escrow_id, dispute_id = await _setup_disputed_escrow(
        client, "res4", amount="400.00"
    )
    await _make_admin(db_session, "admin-res4@example.com")
    admin_token = await _login(client, "admin-res4@example.com")

    response = await client.post(
        f"/api/v1/disputes/{dispute_id}/resolve",
        headers=_headers(admin_token),
        json={
            "resolution": "split",
            "release_amount": "150.00",
            "resolution_notes": "Partial delivery",
        },
    )
    assert response.status_code == 200
    assert response.json()["resolution"] == "split"

    escrow_response = await client.get(
        f"/api/v1/escrows/{escrow_id}", headers=_headers(payer["token"])
    )
    assert escrow_response.json()["status"] == "released"

    payer_wallet = await client.get("/api/v1/wallet", headers=_headers(payer["token"]))
    payee_wallet = await client.get("/api/v1/wallet", headers=_headers(payee["token"]))
    # payer: 1000 deposited, 400 held for escrow, 150 released to payee,
    # 250 stays with payer -> balance = 1000 - 150 = 850
    assert payer_wallet.json()["balance"] == "850.00"
    assert payer_wallet.json()["held_balance"] == "0.00"
    assert payee_wallet.json()["balance"] == "150.00"


async def test_split_requires_release_amount(client: AsyncClient, db_session: AsyncSession) -> None:
    _payer, _payee, _escrow_id, dispute_id = await _setup_disputed_escrow(client, "res5")
    await _make_admin(db_session, "admin-res5@example.com")
    admin_token = await _login(client, "admin-res5@example.com")

    response = await client.post(
        f"/api/v1/disputes/{dispute_id}/resolve",
        headers=_headers(admin_token),
        json={"resolution": "split"},
    )
    assert response.status_code == 422


async def test_split_rejects_release_amount_at_or_above_full_amount(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    _payer, _payee, _escrow_id, dispute_id = await _setup_disputed_escrow(
        client, "res-split-full", amount="200.00"
    )
    await _make_admin(db_session, "admin-split-full@example.com")
    admin_token = await _login(client, "admin-split-full@example.com")

    response = await client.post(
        f"/api/v1/disputes/{dispute_id}/resolve",
        headers=_headers(admin_token),
        json={"resolution": "split", "release_amount": "200.00"},
    )
    assert response.status_code == 422
    assert "release/refund" in response.json()["detail"]


async def test_split_requires_the_escrow_to_be_disputed(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    """Splitting is only for disputes — an already-resolved (RELEASED)
    escrow can't retroactively be split.
    """
    payer, payee, escrow_id, dispute_id = await _setup_disputed_escrow(
        client, "res-split-notdisputed", amount="200.00"
    )
    await _make_admin(db_session, "admin-split-notdisputed@example.com")
    admin_token = await _login(client, "admin-split-notdisputed@example.com")

    # Resolve normally first, moving the escrow to RELEASED.
    await client.post(
        f"/api/v1/disputes/{dispute_id}/resolve",
        headers=_headers(admin_token),
        json={"resolution": "release_to_payee"},
    )

    # A second, fabricated dispute row pointed at the now-RELEASED escrow
    # would be needed to hit this via HTTP naturally; instead, directly
    # exercise the engine's own guard against a non-disputed escrow.
    result = await db_session.execute(
        select(User).where(User.email == "admin-split-notdisputed@example.com")
    )
    admin_user = result.scalar_one()

    with pytest.raises(InvalidStateTransitionError):
        await EscrowTransactionEngine(db_session).split(
            escrow_id, current_user=admin_user, release_amount=Decimal("50.00")
        )


async def test_release_amount_rejected_for_non_split_resolutions(client: AsyncClient) -> None:
    _payer, _payee, _escrow_id, dispute_id = await _setup_disputed_escrow(client, "res-noamt")
    # No admin needed to prove this — Pydantic rejects the shape before
    # the request even reaches DisputeService.
    response = await client.post(
        f"/api/v1/disputes/{dispute_id}/resolve",
        headers=_headers(_payer["token"]),
        json={"resolution": "release_to_payee", "release_amount": "10.00"},
    )
    assert response.status_code == 422


async def test_cannot_resolve_an_already_resolved_dispute(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    _payer, _payee, _escrow_id, dispute_id = await _setup_disputed_escrow(client, "res6")
    await _make_admin(db_session, "admin-res6@example.com")
    admin_token = await _login(client, "admin-res6@example.com")

    first = await client.post(
        f"/api/v1/disputes/{dispute_id}/resolve",
        headers=_headers(admin_token),
        json={"resolution": "release_to_payee"},
    )
    second = await client.post(
        f"/api/v1/disputes/{dispute_id}/resolve",
        headers=_headers(admin_token),
        json={"resolution": "refund_to_payer"},
    )
    assert first.status_code == 200
    assert second.status_code == 422


async def test_both_parties_get_notified_on_resolution(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    payer, payee, _escrow_id, dispute_id = await _setup_disputed_escrow(client, "res7")
    await _make_admin(db_session, "admin-res7@example.com")
    admin_token = await _login(client, "admin-res7@example.com")

    await client.post(
        f"/api/v1/disputes/{dispute_id}/resolve",
        headers=_headers(admin_token),
        json={"resolution": "release_to_payee"},
    )

    payer_notifications = await client.get(
        "/api/v1/notifications", headers=_headers(payer["token"])
    )
    payee_notifications = await client.get(
        "/api/v1/notifications", headers=_headers(payee["token"])
    )
    assert any(n["reference_id"] == dispute_id for n in payer_notifications.json())
    assert any(n["reference_id"] == dispute_id for n in payee_notifications.json())
