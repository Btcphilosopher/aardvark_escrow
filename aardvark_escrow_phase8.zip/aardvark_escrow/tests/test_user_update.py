"""Integration tests for PATCH /users/me."""
from httpx import AsyncClient

EMAIL = "profile@example.com"
PASSWORD = "correct-horse-42"


async def _register(client: AsyncClient) -> dict[str, str]:
    response = await client.post(
        "/api/v1/auth/register",
        json={"email": EMAIL, "password": PASSWORD, "full_name": "Original Name"},
    )
    body = response.json()
    return {"Authorization": f"Bearer {body['access_token']}"}


async def test_update_full_name(client: AsyncClient) -> None:
    headers = await _register(client)
    response = await client.patch(
        "/api/v1/users/me", headers=headers, json={"full_name": "New Name"}
    )
    assert response.status_code == 200
    assert response.json()["full_name"] == "New Name"


async def test_update_email_resets_verification_and_accepts_new_login(
    client: AsyncClient,
) -> None:
    headers = await _register(client)
    response = await client.patch(
        "/api/v1/users/me", headers=headers, json={"email": "new-address@example.com"}
    )
    assert response.status_code == 200
    body = response.json()
    assert body["email"] == "new-address@example.com"
    assert body["is_verified"] is False

    login = await client.post(
        "/api/v1/auth/login",
        json={"email": "new-address@example.com", "password": PASSWORD},
    )
    assert login.status_code == 200


async def test_update_email_rejects_duplicate(client: AsyncClient) -> None:
    await client.post(
        "/api/v1/auth/register",
        json={
            "email": "taken@example.com",
            "password": PASSWORD,
            "full_name": "Someone Else",
        },
    )
    headers = await _register(client)

    response = await client.patch(
        "/api/v1/users/me", headers=headers, json={"email": "taken@example.com"}
    )
    assert response.status_code == 409


async def test_update_password_requires_current_password(client: AsyncClient) -> None:
    headers = await _register(client)
    response = await client.patch(
        "/api/v1/users/me", headers=headers, json={"new_password": "brand-new-pass-1"}
    )
    assert response.status_code == 422  # Pydantic model_validator rejects this shape


async def test_update_password_with_wrong_current_password_is_rejected(
    client: AsyncClient,
) -> None:
    headers = await _register(client)
    response = await client.patch(
        "/api/v1/users/me",
        headers=headers,
        json={"current_password": "totally-wrong", "new_password": "brand-new-pass-1"},
    )
    assert response.status_code == 401


async def test_update_password_succeeds_and_old_password_stops_working(
    client: AsyncClient,
) -> None:
    headers = await _register(client)
    response = await client.patch(
        "/api/v1/users/me",
        headers=headers,
        json={"current_password": PASSWORD, "new_password": "brand-new-pass-1"},
    )
    assert response.status_code == 200

    old_login = await client.post(
        "/api/v1/auth/login", json={"email": EMAIL, "password": PASSWORD}
    )
    assert old_login.status_code == 401

    new_login = await client.post(
        "/api/v1/auth/login", json={"email": EMAIL, "password": "brand-new-pass-1"}
    )
    assert new_login.status_code == 200


async def test_update_with_no_fields_is_rejected(client: AsyncClient) -> None:
    headers = await _register(client)
    response = await client.patch("/api/v1/users/me", headers=headers, json={})
    assert response.status_code == 422


async def test_update_requires_authentication(client: AsyncClient) -> None:
    response = await client.patch("/api/v1/users/me", json={"full_name": "Nobody"})
    assert response.status_code == 401
