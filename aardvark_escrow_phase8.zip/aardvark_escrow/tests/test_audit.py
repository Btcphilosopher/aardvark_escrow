"""Integration tests for GET /audit — admin-only."""
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.entities.enums import UserRole
from app.domain.entities.user import User
from app.security.password import hash_password

PASSWORD = "correct-horse-42"


async def _register(client: AsyncClient, email: str, full_name: str = "Test User") -> str:
    response = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": PASSWORD, "full_name": full_name},
    )
    return str(response.json()["access_token"])


async def _make_admin_and_login(client: AsyncClient, db_session: AsyncSession, email: str) -> str:
    user = User(
        email=email, hashed_password=hash_password(PASSWORD), full_name="Admin", role=UserRole.ADMIN
    )
    db_session.add(user)
    await db_session.commit()
    response = await client.post("/api/v1/auth/login", json={"email": email, "password": PASSWORD})
    return str(response.json()["access_token"])


def _headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


async def test_audit_log_requires_admin(client: AsyncClient) -> None:
    token = await _register(client, "regular-user-audit@example.com")
    response = await client.get("/api/v1/audit", headers=_headers(token))
    assert response.status_code == 403


async def test_audit_log_requires_authentication(client: AsyncClient) -> None:
    response = await client.get("/api/v1/audit")
    assert response.status_code == 401


async def test_admin_can_list_recent_audit_logs(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    # Registration itself writes a USER_REGISTERED audit row (Phase 3).
    await _register(client, "audited-user@example.com")
    admin_token = await _make_admin_and_login(client, db_session, "admin-audit@example.com")

    response = await client.get("/api/v1/audit", headers=_headers(admin_token))
    assert response.status_code == 200
    body = response.json()
    assert len(body) > 0
    assert any(entry["action"] == "user.registered" for entry in body)


async def test_audit_log_respects_limit(client: AsyncClient, db_session: AsyncSession) -> None:
    admin_token = await _make_admin_and_login(client, db_session, "admin-audit-limit@example.com")
    for i in range(5):
        await _register(client, f"limit-test-{i}@example.com")

    response = await client.get(
        "/api/v1/audit", headers=_headers(admin_token), params={"limit": 2}
    )
    assert response.status_code == 200
    assert len(response.json()) == 2
