"""Unit tests for the security primitives — no database or network needed.

These exercise app.security directly rather than through the API, so a
regression here points straight at the crypto/token logic rather than
requiring a trip through the full HTTP stack to diagnose.
"""
from datetime import UTC, datetime, timedelta
from uuid import uuid4

import jwt
import pytest

from app.core.config import settings
from app.core.exceptions import AuthenticationError
from app.domain.entities.enums import UserRole
from app.security.api_keys import generate_api_key, hash_api_key
from app.security.jwt import create_access_token, decode_access_token
from app.security.password import hash_password, verify_password
from app.security.refresh_tokens import generate_refresh_token, hash_refresh_token


def test_password_hash_is_not_the_plaintext() -> None:
    hashed = hash_password("correct-horse-42")
    assert hashed != "correct-horse-42"
    assert hashed.startswith("$argon2")


def test_password_hash_verifies_correct_password() -> None:
    hashed = hash_password("correct-horse-42")
    assert verify_password("correct-horse-42", hashed) is True


def test_password_hash_rejects_wrong_password() -> None:
    hashed = hash_password("correct-horse-42")
    assert verify_password("wrong-password", hashed) is False


def test_same_password_hashes_differently_each_time() -> None:
    # Argon2 uses a random salt per hash — this is what prevents two
    # users with the same password from having identical DB rows.
    assert hash_password("correct-horse-42") != hash_password("correct-horse-42")


def test_access_token_round_trips() -> None:
    user_id = uuid4()
    token = create_access_token(user_id, UserRole.ADMIN)
    payload = decode_access_token(token)
    assert payload.user_id == user_id
    assert payload.role == UserRole.ADMIN


def test_access_token_rejects_bad_signature() -> None:
    forged = jwt.encode(
        {"sub": str(uuid4()), "role": "user", "type": "access",
         "iat": datetime.now(UTC), "exp": datetime.now(UTC) + timedelta(minutes=5)},
        "wrong-secret-key",
        algorithm=settings.JWT_ALGORITHM,
    )
    with pytest.raises(AuthenticationError):
        decode_access_token(forged)


def test_access_token_rejects_expired_token() -> None:
    now = datetime.now(UTC)
    expired = jwt.encode(
        {
            "sub": str(uuid4()),
            "role": "user",
            "type": "access",
            "iat": now - timedelta(hours=1),
            "exp": now - timedelta(minutes=1),
        },
        settings.JWT_SECRET_KEY,
        algorithm=settings.JWT_ALGORITHM,
    )
    with pytest.raises(AuthenticationError):
        decode_access_token(expired)


def test_access_token_rejects_wrong_token_type() -> None:
    now = datetime.now(UTC)
    wrong_type = jwt.encode(
        {
            "sub": str(uuid4()),
            "role": "user",
            "type": "refresh",  # access tokens must say "access"
            "iat": now,
            "exp": now + timedelta(minutes=5),
        },
        settings.JWT_SECRET_KEY,
        algorithm=settings.JWT_ALGORITHM,
    )
    with pytest.raises(AuthenticationError):
        decode_access_token(wrong_type)


def test_refresh_token_hash_is_deterministic_and_lookup_safe() -> None:
    raw = generate_refresh_token()
    assert hash_refresh_token(raw) == hash_refresh_token(raw)
    assert hash_refresh_token(raw) != raw


def test_refresh_tokens_are_unique() -> None:
    assert generate_refresh_token() != generate_refresh_token()


def test_api_key_prefix_is_a_prefix_of_the_raw_key() -> None:
    raw_key, prefix = generate_api_key()
    assert raw_key.startswith(prefix)
    assert len(prefix) < len(raw_key)


def test_api_key_hash_is_deterministic() -> None:
    raw_key, _ = generate_api_key()
    assert hash_api_key(raw_key) == hash_api_key(raw_key)
