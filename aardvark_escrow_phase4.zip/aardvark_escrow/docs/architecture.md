# Architecture

## Goals

Aardvark Escrow holds money on behalf of two or more parties and moves it
only when the agreed conditions are met. Everything about the design
follows from that one sentence:

- **Correctness over speed.** Every fund-moving operation runs inside a
  database transaction with row-level locking; nothing is "eventually
  consistent" when it comes to a balance.
- **Auditability by construction.** Every state transition and every
  money movement writes an immutable audit record. There is no delete
  path for audit data.
- **Framework-agnostic domain.** Business rules (the escrow state
  machine, wallet invariants) live in `app/domain` and know nothing about
  FastAPI, SQLAlchemy sessions, or HTTP. They can be unit tested with
  plain Python objects.

## Layering (Clean Architecture / DDD)

```
┌─────────────────────────────────────────────┐
│  API layer (app/api)                         │  HTTP, request/response
│  — FastAPI routers, Pydantic schemas         │    mapping only. No
├─────────────────────────────────────────────┤    business logic.
│  Service layer (app/domain/services)         │  Orchestrates use cases:
│  — EscrowService, WalletService, ...          │    coordinates repos +
├─────────────────────────────────────────────┤    domain entities inside
│  Domain layer (app/domain/entities)          │    a Unit of Work.
│  — Escrow, Wallet, ... + invariants          │  Pure business rules.
├─────────────────────────────────────────────┤    No I/O.
│  Repository layer (app/domain/repositories)  │  Persistence interfaces;
│  — protocols + SQLAlchemy implementations    │    swappable for tests.
├─────────────────────────────────────────────┤
│  Infrastructure (app/database, app/workers)  │  Engine, sessions,
│  — Postgres, Redis, Celery                   │    Celery, migrations.
└─────────────────────────────────────────────┘
```

Dependencies point inward only: the API layer depends on services, services
depend on repository *interfaces* (not concrete SQLAlchemy code), and the
domain layer depends on nothing. This is what makes the escrow state
machine and wallet arithmetic testable without a running Postgres
instance.

A **Unit of Work** (`app/database/unit_of_work.py`, Phase 4) wraps each
use case that touches more than one repository — e.g. "release escrow"
touches the escrow, both wallets, and the audit log — so the whole
operation commits or rolls back as one unit. `AuthService`,
`UserService`, and `WalletService` all use it today; it was introduced a
phase ahead of the escrow transaction engine that actually needs to
coordinate two independent aggregates, so that engine gets to reuse it
rather than invent transaction handling under time pressure.

Cross-cutting concerns that don't belong to any single use case —
notifying a party that an escrow was funded, generating a report —
are modelled as **domain events** (`app/events`) and handled
asynchronously by Celery workers, keeping the request path fast and the
side effects retryable.

## Escrow state machine

```
CREATED
  │
  ▼
AWAITING_PAYMENT
  │
  ▼
FUNDED ──────────────┐
  │                   │
  ▼                   ▼
IN_PROGRESS        DISPUTED
  │                   │
  ▼                   ▼
AWAITING_APPROVAL   REFUNDED
  │                   │
  ▼                   ▼
RELEASED            CLOSED
```

Transitions are enforced by a single `EscrowStateMachine` (Phase 5) that
is the *only* code path allowed to change an escrow's status. Any
attempted illegal transition raises `InvalidStateTransitionError`
(`app/core/exceptions.py`) rather than silently no-opping, and every
successful transition writes an `EscrowEvent` + `AuditLog` row in the
same database transaction.

## Financial integrity

- All balance-changing operations run inside a single DB transaction and
  take a row lock (`SELECT ... FOR UPDATE`) on the wallet(s) involved,
  preventing two concurrent requests from double-spending the same
  balance. `WalletService.deposit`/`withdraw` (Phase 4) are the first real
  example; the Phase 6 escrow transaction engine follows the same
  pattern across two wallets and an escrow at once.
- **A subtle bug worth documenting explicitly:** a naive `SELECT ... FOR
  UPDATE` is not enough on its own. If the row was already loaded into
  the session earlier in the same request (e.g. by the lazy
  `get_or_create_wallet` lookup that runs just before the locking
  select), SQLAlchemy's identity map hands back the *already-loaded*
  Python object rather than refreshing it from the new, lock-guaranteed-
  current query — silently reintroducing the exact lost-update race the
  lock was supposed to prevent. Both `WalletRepository.get_for_update`
  and `EscrowRepository.get_for_update` pass
  `execution_options(populate_existing=True)` specifically to force that
  refresh. This was caught by testing genuine concurrency (ten parallel
  deposits landing on £10 instead of £100), not by code review — a good
  reminder that locking correctness needs a concurrency test, not just a
  unit test of the happy path.
- Idempotency keys are required on financial POST endpoints. Phase 4's
  wallet deposit/withdraw enforce this via the unique constraint already
  on `WalletTransaction.idempotency_key` (Phase 2): a replayed request
  hits a database conflict, which the service catches and turns into
  "return the original result." Phase 6 generalizes this into a
  Redis-backed pre-check for the escrow transaction engine, which avoids
  even re-running side effects rather than catching the conflict after
  the fact.
- Escrow release/refund is guarded so a given escrow can only ever be
  released or refunded once — enforced both at the state-machine level
  and with a unique constraint at the database level as a second line of
  defence.

## Security model

- **AuthN:** JWT access tokens (15 min default, `app.security.jwt`) issued
  alongside opaque, hashed, individually-revocable refresh tokens
  (`app.security.refresh_tokens`) with rotation on every `/auth/refresh`
  call — a refresh token can only ever be used once. Passwords are hashed
  with Argon2id (`app.security.password`). API keys follow the same
  hash-only-storage pattern (`app.security.api_keys`) for server-to-server
  integration.
- **AuthZ:** `get_current_user` (`app.security.dependencies`) accepts
  either an `X-API-Key` header or a `Authorization: Bearer <jwt>` header,
  so the same protected endpoint serves both interactive users and
  integrating backends. `require_role(*roles)` layers RBAC on top for
  admin-only routes (landing with dispute resolution in Phase 7).
- **Rate limiting:** a Redis-backed fixed-window limiter
  (`app.middleware.rate_limit`) applied per-endpoint — 5/min on register,
  10/min on login — rather than as blanket middleware, since brute-force
  risk varies by endpoint.
- **Secure headers:** `X-Content-Type-Options`, `X-Frame-Options`,
  `Referrer-Policy` on every response; HSTS added only when
  `ENVIRONMENT=production`.
- **CSRF:** deliberately not implemented. CSRF is a threat against
  cookie-based session auth, where a browser attaches credentials to a
  request automatically; this API's auth (JWT Bearer header / API key
  header) is never attached by a browser automatically, so there's no
  ambient credential for a forged cross-site request to ride on. Building
  CSRF protection for a threat model that doesn't apply here would just
  be complexity without a corresponding control.
- **OAuth-ready:** third-party OAuth login isn't implemented (nothing in
  the spec calls for a specific provider), but the shape is ready for it —
  `AuthService._issue_tokens` is the single chokepoint that turns "we've
  verified who this is" into an access/refresh token pair. An OAuth login
  flow would plug in as another way to reach that method, not a parallel
  token system.
- **Idempotency keys + replay protection** for financial endpoints land in
  Phase 6 (the `idempotency_key` columns already exist on
  `WalletTransaction` and `EscrowTransaction` from Phase 2, ready for it).

## Observability

- **Structured logs** (`structlog`) — every log line carries a
  `request_id`, and financial operations additionally carry `escrow_id` /
  `wallet_id`, via `contextvars`.
- **Metrics** (`prometheus-client`) — request latency/count, escrow state
  transition counts, transaction engine error rates.
- **Tracing** (`OpenTelemetry`) — end-to-end spans across the API →
  service → repository → Celery task boundary.
- **Probes** — `/health` (liveness), `/health/live`, `/health/ready`
  (checks DB connectivity) for orchestrator integration.

## Build phases

See the [README](../README.md#build-phases) for the phase list. Each
phase's code lands with its own explanation and leaves the project
runnable before the next phase begins — this document is updated as new
architectural decisions are made along the way.
