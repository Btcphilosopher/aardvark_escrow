"""Domain services.

Business logic that doesn't belong to a single entity lives here.
`AuthService` (Phase 3), `UserService` and `WalletService` (Phase 4) all
follow the same shape: they depend only on repository interfaces via
`app.database.unit_of_work.UnitOfWork`, never on FastAPI directly.
`EscrowStateMachine` and `EscrowTransactionEngine` (Phase 5/6) follow next
— the transaction engine is what the `UnitOfWork` was actually introduced
for, once it needs to coordinate a wallet and an escrow atomically.
"""
