"""Aggregates all v1 API routers into a single mountable router.

Additional routers are wired in here as their phases land:
    Phase 7 — escrows, disputes, audit, notifications
"""
from fastapi import APIRouter

from app.api.v1.endpoints import auth, health, users, wallet

api_router = APIRouter()
api_router.include_router(health.router)
api_router.include_router(auth.router)
api_router.include_router(users.router)
api_router.include_router(wallet.router)
